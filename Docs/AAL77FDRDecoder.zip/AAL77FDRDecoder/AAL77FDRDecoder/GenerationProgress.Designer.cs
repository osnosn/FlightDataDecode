namespace AAL77FDRDecoder
{
    partial class GenerationProgress
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.generationProgressBar = new System.Windows.Forms.ProgressBar();
            this.generateOutputBackgroundWorker = new System.ComponentModel.BackgroundWorker();
            this.SuspendLayout();
            // 
            // generationProgressBar
            // 
            this.generationProgressBar.Location = new System.Drawing.Point(12, 12);
            this.generationProgressBar.Name = "generationProgressBar";
            this.generationProgressBar.Size = new System.Drawing.Size(323, 23);
            this.generationProgressBar.TabIndex = 0;
            // 
            // generateOutputBackgroundWorker
            // 
            this.generateOutputBackgroundWorker.WorkerReportsProgress = true;
            this.generateOutputBackgroundWorker.WorkerSupportsCancellation = true;
            this.generateOutputBackgroundWorker.DoWork += new System.ComponentModel.DoWorkEventHandler(this.generateOutputBackgroundWorker_DoWork);
            this.generateOutputBackgroundWorker.RunWorkerCompleted += new System.ComponentModel.RunWorkerCompletedEventHandler(this.generateOutputBackgroundWorker_RunWorkerCompleted);
            this.generateOutputBackgroundWorker.ProgressChanged += new System.ComponentModel.ProgressChangedEventHandler(this.generateOutputBackgroundWorker_ProgressChanged);
            // 
            // GenerationProgress
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(350, 48);
            this.Controls.Add(this.generationProgressBar);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "GenerationProgress";
            this.ShowInTaskbar = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "Output Progress";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.GenerationProgress_FormClosing);
            this.Load += new System.EventHandler(this.GenerationProgress_Load);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.ProgressBar generationProgressBar;
        private System.ComponentModel.BackgroundWorker generateOutputBackgroundWorker;
    }
}