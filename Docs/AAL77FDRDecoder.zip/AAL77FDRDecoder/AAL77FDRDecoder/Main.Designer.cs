namespace AAL77FDRDecoder
{
    partial class Main
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.finalFlightRadioButton = new System.Windows.Forms.RadioButton();
            this.subFramesRadioButton = new System.Windows.Forms.RadioButton();
            this.panel1 = new System.Windows.Forms.Panel();
            this.replaceBlankValuesWithNullCheckBox = new System.Windows.Forms.CheckBox();
            this.label6 = new System.Windows.Forms.Label();
            this.maximumOneLinePerSubFrameCheckBox = new System.Windows.Forms.CheckBox();
            this.splitOutputFileCheckBox = new System.Windows.Forms.CheckBox();
            this.versionLabel = new System.Windows.Forms.Label();
            this.allSubFramesRadioButton = new System.Windows.Forms.RadioButton();
            this.subFramesToTextBox = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.subFramesFromTextBox = new System.Windows.Forms.TextBox();
            this.panel2 = new System.Windows.Forms.Panel();
            this.chooseButton = new System.Windows.Forms.Button();
            this.rawFDRFileNameTextBox = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.panel3 = new System.Windows.Forms.Panel();
            this.startButton = new System.Windows.Forms.Button();
            this.excludeAllParametersButton = new System.Windows.Forms.Button();
            this.excludeParametersButton = new System.Windows.Forms.Button();
            this.includeAllParametersButton = new System.Windows.Forms.Button();
            this.includeParametersButton = new System.Windows.Forms.Button();
            this.label5 = new System.Windows.Forms.Label();
            this.includedParametersListBox = new System.Windows.Forms.ListBox();
            this.label4 = new System.Windows.Forms.Label();
            this.excludedParametersListBox = new System.Windows.Forms.ListBox();
            this.helpProvider = new System.Windows.Forms.HelpProvider();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.panel3.SuspendLayout();
            this.SuspendLayout();
            // 
            // finalFlightRadioButton
            // 
            this.finalFlightRadioButton.AutoSize = true;
            this.finalFlightRadioButton.Location = new System.Drawing.Point(12, 29);
            this.finalFlightRadioButton.Name = "finalFlightRadioButton";
            this.finalFlightRadioButton.Size = new System.Drawing.Size(374, 17);
            this.finalFlightRadioButton.TabIndex = 1;
            this.finalFlightRadioButton.TabStop = true;
            this.finalFlightRadioButton.Text = "Final Flight  (Subframes from the beginning of those in the NTSB CSV files)";
            this.finalFlightRadioButton.UseVisualStyleBackColor = true;
            this.finalFlightRadioButton.CheckedChanged += new System.EventHandler(this.finalFlightRadioButton_CheckedChanged);
            // 
            // subFramesRadioButton
            // 
            this.subFramesRadioButton.AutoSize = true;
            this.subFramesRadioButton.Location = new System.Drawing.Point(12, 52);
            this.subFramesRadioButton.Name = "subFramesRadioButton";
            this.subFramesRadioButton.Size = new System.Drawing.Size(75, 17);
            this.subFramesRadioButton.TabIndex = 2;
            this.subFramesRadioButton.TabStop = true;
            this.subFramesRadioButton.Text = "Subframes";
            this.subFramesRadioButton.UseVisualStyleBackColor = true;
            this.subFramesRadioButton.CheckedChanged += new System.EventHandler(this.subFramesRadioButton_CheckedChanged);
            // 
            // panel1
            // 
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel1.Controls.Add(this.replaceBlankValuesWithNullCheckBox);
            this.panel1.Controls.Add(this.label6);
            this.panel1.Controls.Add(this.maximumOneLinePerSubFrameCheckBox);
            this.panel1.Controls.Add(this.splitOutputFileCheckBox);
            this.panel1.Controls.Add(this.versionLabel);
            this.panel1.Controls.Add(this.allSubFramesRadioButton);
            this.panel1.Controls.Add(this.subFramesToTextBox);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Controls.Add(this.subFramesFromTextBox);
            this.panel1.Controls.Add(this.subFramesRadioButton);
            this.panel1.Controls.Add(this.finalFlightRadioButton);
            this.panel1.Location = new System.Drawing.Point(12, 53);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(525, 146);
            this.panel1.TabIndex = 2;
            // 
            // replaceBlankValuesWithNullCheckBox
            // 
            this.replaceBlankValuesWithNullCheckBox.AutoSize = true;
            this.replaceBlankValuesWithNullCheckBox.Location = new System.Drawing.Point(12, 121);
            this.replaceBlankValuesWithNullCheckBox.Name = "replaceBlankValuesWithNullCheckBox";
            this.replaceBlankValuesWithNullCheckBox.Size = new System.Drawing.Size(175, 17);
            this.replaceBlankValuesWithNullCheckBox.TabIndex = 12;
            this.replaceBlankValuesWithNullCheckBox.Text = "Replace Blank Values With null";
            this.replaceBlankValuesWithNullCheckBox.UseVisualStyleBackColor = true;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(414, 31);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(91, 13);
            this.label6.TabIndex = 11;
            this.label6.Text = "Press F1 For Help";
            // 
            // maximumOneLinePerSubFrameCheckBox
            // 
            this.maximumOneLinePerSubFrameCheckBox.AutoSize = true;
            this.maximumOneLinePerSubFrameCheckBox.Checked = true;
            this.maximumOneLinePerSubFrameCheckBox.CheckState = System.Windows.Forms.CheckState.Checked;
            this.maximumOneLinePerSubFrameCheckBox.Location = new System.Drawing.Point(12, 98);
            this.maximumOneLinePerSubFrameCheckBox.Name = "maximumOneLinePerSubFrameCheckBox";
            this.maximumOneLinePerSubFrameCheckBox.Size = new System.Drawing.Size(183, 17);
            this.maximumOneLinePerSubFrameCheckBox.TabIndex = 10;
            this.maximumOneLinePerSubFrameCheckBox.Text = "Maximum One Line Per Subframe";
            this.maximumOneLinePerSubFrameCheckBox.UseVisualStyleBackColor = true;
            // 
            // splitOutputFileCheckBox
            // 
            this.splitOutputFileCheckBox.AutoSize = true;
            this.splitOutputFileCheckBox.Location = new System.Drawing.Point(12, 75);
            this.splitOutputFileCheckBox.Name = "splitOutputFileCheckBox";
            this.splitOutputFileCheckBox.Size = new System.Drawing.Size(319, 17);
            this.splitOutputFileCheckBox.TabIndex = 9;
            this.splitOutputFileCheckBox.Text = "Split Output File in to files containing no more than 30000 rows";
            this.splitOutputFileCheckBox.UseVisualStyleBackColor = true;
            // 
            // versionLabel
            // 
            this.versionLabel.Location = new System.Drawing.Point(380, 8);
            this.versionLabel.Name = "versionLabel";
            this.versionLabel.Size = new System.Drawing.Size(125, 13);
            this.versionLabel.TabIndex = 8;
            this.versionLabel.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // allSubFramesRadioButton
            // 
            this.allSubFramesRadioButton.AutoSize = true;
            this.allSubFramesRadioButton.Location = new System.Drawing.Point(12, 6);
            this.allSubFramesRadioButton.Name = "allSubFramesRadioButton";
            this.allSubFramesRadioButton.Size = new System.Drawing.Size(89, 17);
            this.allSubFramesRadioButton.TabIndex = 0;
            this.allSubFramesRadioButton.TabStop = true;
            this.allSubFramesRadioButton.Text = "All Subframes";
            this.allSubFramesRadioButton.UseVisualStyleBackColor = true;
            this.allSubFramesRadioButton.CheckedChanged += new System.EventHandler(this.allSubFramesRadioButton_CheckedChanged);
            // 
            // subFramesToTextBox
            // 
            this.subFramesToTextBox.Location = new System.Drawing.Point(270, 49);
            this.subFramesToTextBox.Name = "subFramesToTextBox";
            this.subFramesToTextBox.Size = new System.Drawing.Size(100, 20);
            this.subFramesToTextBox.TabIndex = 6;
            this.subFramesToTextBox.Leave += new System.EventHandler(this.subFramesToTextBox_Leave);
            this.subFramesToTextBox.Enter += new System.EventHandler(this.subFramesToTextBox_Enter);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(245, 52);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(19, 13);
            this.label2.TabIndex = 5;
            this.label2.Text = "to:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(93, 54);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(30, 13);
            this.label1.TabIndex = 4;
            this.label1.Text = "from:";
            // 
            // subFramesFromTextBox
            // 
            this.subFramesFromTextBox.Location = new System.Drawing.Point(129, 49);
            this.subFramesFromTextBox.Name = "subFramesFromTextBox";
            this.subFramesFromTextBox.Size = new System.Drawing.Size(100, 20);
            this.subFramesFromTextBox.TabIndex = 3;
            this.subFramesFromTextBox.Leave += new System.EventHandler(this.subFramesFromTextBox_Leave);
            this.subFramesFromTextBox.Enter += new System.EventHandler(this.subFramesFromTextBox_Enter);
            // 
            // panel2
            // 
            this.panel2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel2.Controls.Add(this.chooseButton);
            this.panel2.Controls.Add(this.rawFDRFileNameTextBox);
            this.panel2.Controls.Add(this.label3);
            this.panel2.Location = new System.Drawing.Point(12, 13);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(525, 34);
            this.panel2.TabIndex = 3;
            // 
            // chooseButton
            // 
            this.chooseButton.Location = new System.Drawing.Point(89, 4);
            this.chooseButton.Name = "chooseButton";
            this.chooseButton.Size = new System.Drawing.Size(56, 23);
            this.chooseButton.TabIndex = 2;
            this.chooseButton.Text = "Choose";
            this.chooseButton.UseVisualStyleBackColor = true;
            this.chooseButton.Click += new System.EventHandler(this.chooseButton_Click);
            // 
            // rawFDRFileNameTextBox
            // 
            this.rawFDRFileNameTextBox.Location = new System.Drawing.Point(151, 6);
            this.rawFDRFileNameTextBox.Name = "rawFDRFileNameTextBox";
            this.rawFDRFileNameTextBox.Size = new System.Drawing.Size(354, 20);
            this.rawFDRFileNameTextBox.TabIndex = 1;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(10, 9);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(73, 13);
            this.label3.TabIndex = 0;
            this.label3.Text = "Raw FDR File";
            // 
            // panel3
            // 
            this.panel3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel3.Controls.Add(this.startButton);
            this.panel3.Controls.Add(this.excludeAllParametersButton);
            this.panel3.Controls.Add(this.excludeParametersButton);
            this.panel3.Controls.Add(this.includeAllParametersButton);
            this.panel3.Controls.Add(this.includeParametersButton);
            this.panel3.Controls.Add(this.label5);
            this.panel3.Controls.Add(this.includedParametersListBox);
            this.panel3.Controls.Add(this.label4);
            this.panel3.Controls.Add(this.excludedParametersListBox);
            this.panel3.Location = new System.Drawing.Point(12, 205);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(525, 337);
            this.panel3.TabIndex = 4;
            // 
            // startButton
            // 
            this.startButton.Location = new System.Drawing.Point(239, 278);
            this.startButton.Name = "startButton";
            this.startButton.Size = new System.Drawing.Size(50, 23);
            this.startButton.TabIndex = 8;
            this.startButton.Text = "Start";
            this.startButton.UseVisualStyleBackColor = true;
            this.startButton.Click += new System.EventHandler(this.startButton_Click);
            // 
            // excludeAllParametersButton
            // 
            this.excludeAllParametersButton.Location = new System.Drawing.Point(248, 183);
            this.excludeAllParametersButton.Name = "excludeAllParametersButton";
            this.excludeAllParametersButton.Size = new System.Drawing.Size(34, 23);
            this.excludeAllParametersButton.TabIndex = 7;
            this.excludeAllParametersButton.Text = "<<";
            this.excludeAllParametersButton.UseVisualStyleBackColor = true;
            this.excludeAllParametersButton.Click += new System.EventHandler(this.excludeAllParametersButton_Click);
            // 
            // excludeParametersButton
            // 
            this.excludeParametersButton.Location = new System.Drawing.Point(248, 154);
            this.excludeParametersButton.Name = "excludeParametersButton";
            this.excludeParametersButton.Size = new System.Drawing.Size(34, 23);
            this.excludeParametersButton.TabIndex = 6;
            this.excludeParametersButton.Text = "<";
            this.excludeParametersButton.UseVisualStyleBackColor = true;
            this.excludeParametersButton.Click += new System.EventHandler(this.excludeParametersButton_Click);
            // 
            // includeAllParametersButton
            // 
            this.includeAllParametersButton.Location = new System.Drawing.Point(248, 101);
            this.includeAllParametersButton.Name = "includeAllParametersButton";
            this.includeAllParametersButton.Size = new System.Drawing.Size(34, 23);
            this.includeAllParametersButton.TabIndex = 5;
            this.includeAllParametersButton.Text = ">>";
            this.includeAllParametersButton.UseVisualStyleBackColor = true;
            this.includeAllParametersButton.Click += new System.EventHandler(this.includeAllParametersButton_Click);
            // 
            // includeParametersButton
            // 
            this.includeParametersButton.Location = new System.Drawing.Point(248, 72);
            this.includeParametersButton.Name = "includeParametersButton";
            this.includeParametersButton.Size = new System.Drawing.Size(34, 23);
            this.includeParametersButton.TabIndex = 4;
            this.includeParametersButton.Text = ">";
            this.includeParametersButton.UseVisualStyleBackColor = true;
            this.includeParametersButton.Click += new System.EventHandler(this.includeParametersButton_Click);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(346, 7);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(104, 13);
            this.label5.TabIndex = 3;
            this.label5.Text = "Included Parameters";
            // 
            // includedParametersListBox
            // 
            this.includedParametersListBox.FormattingEnabled = true;
            this.includedParametersListBox.Location = new System.Drawing.Point(295, 23);
            this.includedParametersListBox.Name = "includedParametersListBox";
            this.includedParametersListBox.Size = new System.Drawing.Size(210, 290);
            this.includedParametersListBox.TabIndex = 2;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(74, 7);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(107, 13);
            this.label4.TabIndex = 1;
            this.label4.Text = "Excluded Parameters";
            // 
            // excludedParametersListBox
            // 
            this.excludedParametersListBox.FormattingEnabled = true;
            this.excludedParametersListBox.Location = new System.Drawing.Point(19, 23);
            this.excludedParametersListBox.Name = "excludedParametersListBox";
            this.excludedParametersListBox.Size = new System.Drawing.Size(210, 290);
            this.excludedParametersListBox.TabIndex = 0;
            // 
            // Main
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(549, 556);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.Name = "Main";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "AAL77 FDR Decoder";
            this.Load += new System.EventHandler(this.Main_Load);
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.Main_FormClosed);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.RadioButton finalFlightRadioButton;
        private System.Windows.Forms.RadioButton subFramesRadioButton;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.TextBox subFramesFromTextBox;
        private System.Windows.Forms.RadioButton allSubFramesRadioButton;
        private System.Windows.Forms.TextBox subFramesToTextBox;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Button chooseButton;
        private System.Windows.Forms.TextBox rawFDRFileNameTextBox;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.ListBox excludedParametersListBox;
        private System.Windows.Forms.Button includeAllParametersButton;
        private System.Windows.Forms.Button includeParametersButton;
        private System.Windows.Forms.Button startButton;
        private System.Windows.Forms.Button excludeAllParametersButton;
        private System.Windows.Forms.Button excludeParametersButton;
        public System.Windows.Forms.ListBox includedParametersListBox;
        private System.Windows.Forms.HelpProvider helpProvider;
        private System.Windows.Forms.Label versionLabel;
        private System.Windows.Forms.Label label6;
        public System.Windows.Forms.CheckBox maximumOneLinePerSubFrameCheckBox;
        private System.Windows.Forms.CheckBox splitOutputFileCheckBox;
        public System.Windows.Forms.CheckBox replaceBlankValuesWithNullCheckBox;
    }
}

