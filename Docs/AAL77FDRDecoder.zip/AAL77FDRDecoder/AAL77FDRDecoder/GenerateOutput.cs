using System;
using System.Collections.Generic;
using System.Text;
using System.Globalization;
using System.IO;
using System.ComponentModel;

namespace AAL77FDRDecoder
{
    abstract class ParameterRow
    {
        protected int lastWordNum;
        protected int subFrameNumber;
        protected int superFrameNumber;
        protected int MSB;
        protected int LSB;
        protected double offset;
        protected double scalar;
        protected int decimalPlaces;

        protected int FramePosOfWordNum(int wordNum, FlightDataStream flightDataStream)
        {
            return ((flightDataStream.SubFrameNumber - 1) * 255 + wordNum - 2);
        }

        public bool HasValue(FlightDataStream flightDataStream)
        {
            return (((flightDataStream.SubFrameNumber == subFrameNumber) || (subFrameNumber == 0))
                    && ((flightDataStream.SuperFrameNumber == superFrameNumber) || (superFrameNumber == 0))
                    && (FramePosOfWordNum(lastWordNum, flightDataStream) < flightDataStream.LastFramePos));
        }

        protected string FormatValueAsString(int intValue, FlightDataStream flightDataStream)
        {
            double value = (intValue * scalar) + offset;
            string formatString = string.Format("F{0:0}", decimalPlaces);
            return value.ToString(formatString);
        }

        protected int GetUnsignedValue(int aWordNum, int aMSB, int aLSB, FlightDataStream flightDataStream)
        {
            int result = flightDataStream.Frame[FramePosOfWordNum(aWordNum, flightDataStream)];
            result &= ((1 << aMSB) - 1);
            result >>= (aLSB - 1);
            return result;
        }

        protected int GetSignedValue(int aWordNum, int aMSB, int aLSB, FlightDataStream flightDataStream)
        {
            int result = GetUnsignedValue(aWordNum, aMSB, aLSB, flightDataStream);
            int bitMask = 1 << (aMSB - aLSB);
            if ((result & bitMask) != 0)
                result -= (bitMask << 1);
            return result;
        }

        protected int GetBCDValue(int aWordNum, int aMSB, int aLSB, FlightDataStream flightDataStream)
        {
            int BCDValue = GetUnsignedValue(aWordNum, aMSB, aLSB, flightDataStream);
            int result = 0;
            for (int i = (aMSB - aLSB) & -4; i >= 0; i -= 4)
                result = (result * 10) + ((BCDValue >> i) & 0xF);
            return result;
        }

        abstract public string GetValueAsString(FlightDataStream flightDataStream);
    }

    class UnsignedParameterRow : ParameterRow
    {
        public UnsignedParameterRow(int aWordNum, int aSubFrameNumber, int aSuperFrameNumber, int aMSB, int aLSB, double aOffset, double aScalar, int aDecimalPlaces)
        {
            lastWordNum = aWordNum;
            subFrameNumber = aSubFrameNumber;
            superFrameNumber = aSuperFrameNumber;
            MSB = aMSB;
            LSB = aLSB;
            offset = aOffset;
            scalar = aScalar;
            decimalPlaces = aDecimalPlaces;
        }

        public override string GetValueAsString(FlightDataStream flightDataStream)
        {
            return FormatValueAsString(GetUnsignedValue(lastWordNum, MSB, LSB, flightDataStream), flightDataStream);
        }
    }

    class SignedParameterRow : ParameterRow
    {
        public SignedParameterRow(int aWordNum, int aSubFrameNumber, int aSuperFrameNumber, int aMSB, int aLSB, double aOffset, double aScalar, int aDecimalPlaces)
        {
            lastWordNum = aWordNum;
            subFrameNumber = aSubFrameNumber;
            superFrameNumber = aSuperFrameNumber;
            MSB = aMSB;
            LSB = aLSB;
            offset = aOffset;
            scalar = aScalar;
            decimalPlaces = aDecimalPlaces;
        }

        public override string GetValueAsString(FlightDataStream flightDataStream)
        {
            return FormatValueAsString(GetSignedValue(lastWordNum, MSB, LSB, flightDataStream), flightDataStream);
        }
    }

    class BCDParameterRow : ParameterRow
    {
        public BCDParameterRow(int aWordNum, int aSubFrameNumber, int aSuperFrameNumber, int aMSB, int aLSB, double aOffset, double aScalar, int aDecimalPlaces)
        {
            lastWordNum = aWordNum;
            subFrameNumber = aSubFrameNumber;
            superFrameNumber = aSuperFrameNumber;
            MSB = aMSB;
            LSB = aLSB;
            offset = aOffset;
            scalar = aScalar;
            decimalPlaces = aDecimalPlaces;
        }

        public override string GetValueAsString(FlightDataStream flightDataStream)
        {
            return FormatValueAsString(GetBCDValue(lastWordNum, MSB, LSB, flightDataStream), flightDataStream);
        }
    }

    class ZeroOneParameterRow : ParameterRow
    {
        protected string zeroValue;
        protected string oneValue;

        public ZeroOneParameterRow(int aWordNum, int aSubFrameNumber, int aSuperFrameNumber, int aMSBLSB, string aZeroValue, string aOneValue)
        {
            lastWordNum = aWordNum;
            subFrameNumber = aSubFrameNumber;
            superFrameNumber = aSuperFrameNumber;
            MSB = aMSBLSB;
            LSB = aMSBLSB;
            zeroValue = aZeroValue;
            oneValue = aOneValue;
        }

        public override string GetValueAsString(FlightDataStream flightDataStream)
        {
            if (GetUnsignedValue(lastWordNum, MSB, LSB, flightDataStream) == 0)
                return zeroValue;
            else
                return oneValue;
        }
    }

    class CharacterParameterRow : ParameterRow
    {
        public CharacterParameterRow(int aWordNum, int aSubFrameNumber, int aSuperFrameNumber, int aMSB, int aLSB)
        {
            lastWordNum = aWordNum;
            subFrameNumber = aSubFrameNumber;
            superFrameNumber = aSuperFrameNumber;
            MSB = aMSB;
            LSB = aLSB;
        }

        public override string GetValueAsString(FlightDataStream flightDataStream)
        {
            return (GetUnsignedValue(lastWordNum, MSB, LSB, flightDataStream)).ToString();
        }
    }

    class AltitudeParameterRow : ParameterRow
    {
        public AltitudeParameterRow()
        {
            lastWordNum = 30;
            subFrameNumber = 0;
            superFrameNumber = 0;
            offset = 0.0;
            scalar = 1.0;
            decimalPlaces = 0;
        }

        public override string GetValueAsString(FlightDataStream flightDataStream)
        {
            return FormatValueAsString((GetUnsignedValue(29, 12, 12, flightDataStream) * -65536) + (GetUnsignedValue(29, 11, 3, flightDataStream) * 128) + GetUnsignedValue(30, 9, 3, flightDataStream), flightDataStream);
        }
    }

    class PressureAltitudeParameterRow : ParameterRow
    {
        public PressureAltitudeParameterRow()
        {
            lastWordNum = 30;
            subFrameNumber = 0;
            superFrameNumber = 0;
            offset = 0.0;
            scalar = 1.0;
            decimalPlaces = 0;
        }

        public override string GetValueAsString(FlightDataStream flightDataStream)
        {
            return FormatValueAsString((GetSignedValue(29, 12, 3, flightDataStream) * 128) + GetSignedValue(30, 12, 3, flightDataStream), flightDataStream);
        }
    }

    class LatitudeParameterRow : ParameterRow
    {
        public LatitudeParameterRow()
        {
            lastWordNum = 60;
            subFrameNumber = 0;
            superFrameNumber = 0;
            offset = 0.0;
            scalar = 180.0 / 1048576;
            decimalPlaces = 5;
        }

        public override string GetValueAsString(FlightDataStream flightDataStream)
        {
            return FormatValueAsString((GetSignedValue(60, 12, 3, flightDataStream) * 2048) + GetUnsignedValue(59, 11, 1, flightDataStream), flightDataStream);
        }
    }

    class LongitudeParameterRow : ParameterRow
    {
        public LongitudeParameterRow()
        {
            lastWordNum = 62;
            subFrameNumber = 0;
            superFrameNumber = 0;
            offset = 0.0;
            scalar = 180.0 / 1048576;
            decimalPlaces = 5;
        }

        public override string GetValueAsString(FlightDataStream flightDataStream)
        {
            return FormatValueAsString((GetSignedValue(62, 12, 3, flightDataStream) * 2048) + GetUnsignedValue(61, 11, 1, flightDataStream), flightDataStream);
        }
    }

    class RadioHeightParameterRow : ParameterRow
    {
        public RadioHeightParameterRow(int aSubFrameNumber)
        {
            lastWordNum = 32;
            subFrameNumber = aSubFrameNumber;
            superFrameNumber = 0;
            offset = 0.0;
            scalar = 1.0;
            decimalPlaces = 0;
        }

        public override string GetValueAsString(FlightDataStream flightDataStream)
        {
            return FormatValueAsString((GetUnsignedValue(31, 12, 12, flightDataStream) * -8192) + (GetUnsignedValue(32, 2, 1, flightDataStream) * 2048) + GetUnsignedValue(31, 11, 1, flightDataStream), flightDataStream);
        }
    }

    class VORFrequencyRow : ParameterRow
    {
        public VORFrequencyRow(int aSubFrameNumber)
        {
            lastWordNum = 222;
            subFrameNumber = aSubFrameNumber;
            superFrameNumber = 0;
            offset = 100.0;
            scalar = 0.001;
            decimalPlaces = 2;
        }

        public override string GetValueAsString(FlightDataStream flightDataStream)
        {
            return FormatValueAsString((GetBCDValue(222, 12, 4, flightDataStream) * 100) + (GetUnsignedValue(222, 3, 2, flightDataStream) * 50), flightDataStream);
        }
    }

    class SyncWordParameterRow : ParameterRow
    {
        public SyncWordParameterRow()
        {
            lastWordNum = 1;
            subFrameNumber = 0;
            superFrameNumber = 0;
            offset = 0.0;
            scalar = 1.0;
            decimalPlaces = 0;
        }

        public override string GetValueAsString(FlightDataStream flightDataStream)
        {
            return FormatValueAsString(flightDataStream.SubFrameNumber - 1, flightDataStream);
        }
    }

    class FilePosParameterRow : ParameterRow
    {
        public FilePosParameterRow()
        {
            lastWordNum = 0;
            subFrameNumber = 1;
            superFrameNumber = 0;
        }

        public override string GetValueAsString(FlightDataStream flightDataStream)
        {
            return string.Format("{0:X}h", flightDataStream.FilePos);
        }
    }

    class SyncLostParameterRow : ParameterRow
    {
        public SyncLostParameterRow()
        {
            lastWordNum = 0;
            subFrameNumber = 1;
            superFrameNumber = 0;
        }

        public override string GetValueAsString(FlightDataStream flightDataStream)
        {
            return flightDataStream.SyncLost ? "Sync Lost" : "";
        }
    }

    class LastFramePosParameterRow : ParameterRow
    {
        public LastFramePosParameterRow()
        {
            lastWordNum = 0;
            subFrameNumber = 1;
            superFrameNumber = 0;
            offset = 0.0;
            scalar = 1.0;
            decimalPlaces = 0;
        }

        public override string GetValueAsString(FlightDataStream flightDataStream)
        {
            return FormatValueAsString(flightDataStream.LastFramePos, flightDataStream);
        }
    }

    class SuperFrameNumberParameterRow : ParameterRow
    {
        public SuperFrameNumberParameterRow()
        {
            lastWordNum = 0;
            subFrameNumber = 1;
            superFrameNumber = 0;
            offset = 0.0;
            scalar = 1.0;
            decimalPlaces = 0;
        }

        public override string GetValueAsString(FlightDataStream flightDataStream)
        {
            return FormatValueAsString(flightDataStream.SuperFrameNumber, flightDataStream);
        }
    }

    class FlapHandlePositionParameterRow : ParameterRow
    {
        public FlapHandlePositionParameterRow(int aWordNum)
        {
            lastWordNum = aWordNum;
            subFrameNumber = 0;
            superFrameNumber = 0;
            offset = 0.0;
            scalar = 0.1;
            decimalPlaces = 1;
        }

        public override string GetValueAsString(FlightDataStream flightDataStream)
        {
            double V = GetUnsignedValue(lastWordNum, 12, 3, flightDataStream) * 0.004882813;
            double F = -4.292969 + 9.640625 * V - 7.429688 * V * V + 2.080078 * V * V * V;
            if (F > 15.0)
                F = -8.527527 + 7.703903 * V;
            return FormatValueAsString((int)(F * 10.0), flightDataStream);
        }
    }

    class CaptContColumnPosnParameterRow : ParameterRow
    {
        public CaptContColumnPosnParameterRow(int aWordNum)
        {
            lastWordNum = aWordNum;
            subFrameNumber = 0;
            superFrameNumber = 0;
            offset = 0.0;
            scalar = 0.1;
            decimalPlaces = 1;
        }

        public override string GetValueAsString(FlightDataStream flightDataStream)
        {
            double rawValue = GetSignedValue(lastWordNum, 12, 1, flightDataStream);
            //double value = -3.24812954667109E-08 * rawValue * rawValue * rawValue - 7.17597222107931E-07 * rawValue * rawValue + 0.0417599231586643 * rawValue + 2.99894283683189;
            double value = -3.248E-08 * rawValue * rawValue * rawValue - 7.176E-07 * rawValue * rawValue + 0.04176 * rawValue + 3.0;
            return FormatValueAsString((int)(value * 10.0), flightDataStream);
        }
    }

    class ManufacturerCodeParameterRow : ParameterRow
    {
        public ManufacturerCodeParameterRow()
        {
            lastWordNum = 256;
            subFrameNumber = 4;
            superFrameNumber = 1;
        }

        public override string GetValueAsString(FlightDataStream flightDataStream)
        {
            switch (GetUnsignedValue(lastWordNum, 5, 1, flightDataStream))
            {
                case 2:
                    return "TELEDYNE";
                case 3:
                    return "ALLIEDSIGNAL";
                case 4:
                    return "SFIM";
                default:
                    return "UNKNOWN";
            }
        }
    }

    class AircraftTypeParameterRow : ParameterRow
    {
        public AircraftTypeParameterRow()
        {
            lastWordNum = 256;
            subFrameNumber = 4;
            superFrameNumber = 1;
        }

        public override string GetValueAsString(FlightDataStream flightDataStream)
        {
            switch (GetUnsignedValue(lastWordNum, 12, 6, flightDataStream))
            {
                case 0x03:
                    return "757-200 RR";
                case 0x04:
                    return "757-200 PW";
                case 0x43:
                    return "757-300 RR";
                case 0x44:
                    return "757-300 PW";
                default:
                    return "UNKNOWN";
            }
        }
    }

    class EICASOPSParameterRow : ParameterRow
    {
        int MSBits = 0;
        int LSBits = 0;

        public EICASOPSParameterRow()
        {
            lastWordNum = 255;
            subFrameNumber = 4;
            superFrameNumber = 0;
            offset = 0.0;
            scalar = 1.0;
            decimalPlaces = 0;
        }

        public override string GetValueAsString(FlightDataStream flightDataStream)
        {
            switch (flightDataStream.SuperFrameNumber)
            {
                case 2:
                    MSBits = GetUnsignedValue(lastWordNum, 12, 1, flightDataStream);
                    break;
                case 4:
                    LSBits = GetUnsignedValue(lastWordNum, 12, 7, flightDataStream);
                    break;
            }
            return FormatValueAsString((MSBits << 6) | LSBits, flightDataStream);
        }
    }

    class EICASOPCParameterRow : ParameterRow
    {
        int MSBits = 0;
        int LSBits = 0;

        public EICASOPCParameterRow()
        {
            lastWordNum = 255;
            subFrameNumber = 4;
            superFrameNumber = 0;
            offset = 0.0;
            scalar = 1.0;
            decimalPlaces = 0;
        }

        public override string GetValueAsString(FlightDataStream flightDataStream)
        {
            switch (flightDataStream.SuperFrameNumber)
            {
                case 3:
                    MSBits = GetUnsignedValue(lastWordNum, 12, 1, flightDataStream);
                    break;
                case 4:
                    LSBits = GetUnsignedValue(lastWordNum, 6, 1, flightDataStream);
                    break;
            }
            return FormatValueAsString((MSBits << 6) | LSBits, flightDataStream);
        }
    }

    class ParameterColumn
    {
        private List<ParameterRow> parameterRows;
        private string columnName;

        public ParameterColumn(string aColumnName, params ParameterRow[] aParameterRows)
        {
            columnName = aColumnName;
            parameterRows = new List<ParameterRow>(aParameterRows);
        }

        public string ColumnName
        {
            get
            {
                return columnName;
            }
        }

        //Return the string representation of occurrence number lineNum of the parameter in the subFrame
        public string GetValueAsString(int lineNum, FlightDataStream flightDataStream)
        {
            foreach (ParameterRow parameterRow in parameterRows)
                if (parameterRow.HasValue(flightDataStream))
                    if (lineNum-- <= 0)
                        return parameterRow.GetValueAsString(flightDataStream);
            return "";
        }
    }

    class Parameter : IComparable<Parameter>, IEquatable<Parameter>
    {
        private List<ParameterColumn> columns;
        private string name;
        private string units;

        public Parameter(string aName, string aUnits, params ParameterColumn[] aColumns)
        {
            name = aName;
            units = aUnits;
            columns = new List<ParameterColumn>(aColumns);
        }

        public int CompareTo(Parameter parameter)
        {
            return ToString().CompareTo(parameter.ToString());
        }

        public bool Equals(Parameter parameter)
        {
            return (ToString() == parameter.ToString());
        }

        public override string ToString()
        {
            string s = name;
            s = s.Replace("^ ", "");
            s = s.Replace("^", "");
            s = s.TrimEnd(null);
            return s;
        }

        public List<ParameterColumn> Columns
        {
            get
            {
                return columns;
            }
        }

        public List<string> ParameterNames
        {
            get
            {
                List<string> parameterNames = new List<string>();
                //Build each parameterName by replacing the ^ characters in the name parameter with detail from the columns
                foreach (ParameterColumn parameterColumn in columns)
                {
                    string parameterName = name;
                    string columnName = parameterColumn.ColumnName;
                    int startPos = 0;
                    while (true)
                    {
                        int i = parameterName.IndexOf('^');
                        if (i < 0)
                            break;
                        int endPos = columnName.IndexOf(',', startPos);
                        if (endPos < 0)
                            endPos = columnName.Length;
                        parameterName = parameterName.Remove(i, 1);
                        parameterName = parameterName.Insert(i, columnName.Substring(startPos, endPos - startPos));
                        startPos = endPos + 1;
                    }
                    if (units != "")
                        parameterName += " " + units;
                    parameterNames.Add(parameterName);
                }
                return parameterNames;
            }
        }
    }

    class ParametersList : List<Parameter>
    {
        public ParametersList()
        {
            Add(new Parameter("ALTITUDE (1013.25mB)", "(FEET)",
                new ParameterColumn("", new AltitudeParameterRow())));
            Add(new Parameter("COMPUTED AIRSPEED", "(KNOTS)",
                new ParameterColumn("", new UnsignedParameterRow(96, 0, 0, 12, 3, 0.0, 1.0 / 2, 1))));
            Add(new Parameter("DME DISTANCE ^", "(NM)",
                new ParameterColumn("- LEFT", new UnsignedParameterRow(222, 3, 0, 12, 3, 0.0, 0.25, 2)),
                new ParameterColumn("- RIGHT", new UnsignedParameterRow(222, 1, 0, 12, 3, 0.0, 0.25, 2))));
            Add(new Parameter("FRAME COUNTER", "",
                new ParameterColumn("", new UnsignedParameterRow(256, 1, 0, 12, 1, 0.0, 1.0, 0))));
            Add(new Parameter("GMT ^", "",
                //new ParameterColumn("MONTH", new BCDParameterRow(256, 4, 5, 6, 2, 0.0, 1.0, 0)),
                //new ParameterColumn("DAY", new BCDParameterRow(256, 4, 5, 12, 7, 0.0, 1.0, 0)),
                //new ParameterColumn("YEAR", new BCDParameterRow(256, 4, 6, 12, 5, 0.0, 1.0, 0)),
                new ParameterColumn("HOURS", new UnsignedParameterRow(255, 1, 0, 12, 8, 0.0, 1.0, 0)),
                new ParameterColumn("MINUTES", new UnsignedParameterRow(255, 1, 0, 7, 2, 0.0, 1.0, 0)),
                new ParameterColumn("SECONDS", new UnsignedParameterRow(254, 1, 0, 12, 7, 0.0, 1.0, 0))));
            Add(new Parameter("GPS ^", "",
                new ParameterColumn("", new ZeroOneParameterRow(254, 2, 0, 5, "INOPER", "OPER"))));
            //new ParameterColumn("", new ZeroOneParameterRow(254, 2, 0, 5, "INOPER", "OPER")),
            //new ParameterColumn("HOURS", new UnsignedParameterRow(256, 4, 8, 12, 8, 0.0, 1.0, 0)),
            //new ParameterColumn("MINUTES", new UnsignedParameterRow(256, 4, 8, 7, 2, 0.0, 1.0, 0)),
            //new ParameterColumn("SECONDS", new UnsignedParameterRow(256, 4, 7, 12, 7, 0.0, 1.0, 0))));
            Add(new Parameter("GROUND PROX WARNING", "",
                new ParameterColumn("", new ZeroOneParameterRow(86, 0, 0, 1, "NOT TRUE", "TRUE"))));
            Add(new Parameter("Raw LATERAL ACCELERATION", "",
                new ParameterColumn("",
                    new UnsignedParameterRow(35, 0, 0, 12, 3, 0.0, 1.0, 0),
                    new UnsignedParameterRow(99, 0, 0, 12, 3, 0.0, 1.0, 0),
                    new UnsignedParameterRow(163, 0, 0, 12, 3, 0.0, 1.0, 0),
                    new UnsignedParameterRow(227, 0, 0, 12, 3, 0.0, 1.0, 0))));
            Add(new Parameter("LATERAL ACCELERATION", "(G's)",
                new ParameterColumn("",
                    new UnsignedParameterRow(35, 0, 0, 12, 3, -1.064285, 0.00203649, 3),
                    new UnsignedParameterRow(99, 0, 0, 12, 3, -1.064285, 0.00203649, 3),
                    new UnsignedParameterRow(163, 0, 0, 12, 3, -1.064285, 0.00203649, 3),
                    new UnsignedParameterRow(227, 0, 0, 12, 3, -1.064285, 0.00203649, 3))));
            Add(new Parameter("Raw LONGITUDINAL ACCEL", "",
                new ParameterColumn("",
                    new UnsignedParameterRow(33, 0, 0, 12, 3, 0.0, 1.0, 0),
                    new UnsignedParameterRow(97, 0, 0, 12, 3, 0.0, 1.0, 0),
                    new UnsignedParameterRow(161, 0, 0, 12, 3, 0.0, 1.0, 0),
                    new UnsignedParameterRow(225, 0, 0, 12, 3, 0.0, 1.0, 0))));
            Add(new Parameter("LONGITUDINAL ACCEL", "(G's)",
                new ParameterColumn("",
                    new UnsignedParameterRow(33, 0, 0, 12, 3, -1.083333, 0.00203649, 3),
                    new UnsignedParameterRow(97, 0, 0, 12, 3, -1.083333, 0.00203649, 3),
                    new UnsignedParameterRow(161, 0, 0, 12, 3, -1.083333, 0.00203649, 3),
                    new UnsignedParameterRow(225, 0, 0, 12, 3, -1.083333, 0.00203649, 3))));
            Add(new Parameter("Raw PRES POSN ^", "",
                new ParameterColumn("LAT-MSData", new SignedParameterRow(60, 0, 0, 12, 3, 0.0, 1.0, 0)),
                new ParameterColumn("LAT-LSData", new UnsignedParameterRow(59, 0, 0, 12, 1, 0.0, 1.0, 0)),
                new ParameterColumn("LONG-MSData", new SignedParameterRow(62, 0, 0, 12, 3, 0.0, 1.0, 0)),
                new ParameterColumn("LONG-LSData", new UnsignedParameterRow(61, 0, 0, 12, 1, 0.0, 1.0, 0))));
            Add(new Parameter("PRES POSN ^", "(DEG)",
                new ParameterColumn("LAT", new LatitudeParameterRow()),
                new ParameterColumn("LONG", new LongitudeParameterRow())));
            Add(new Parameter("RADIO HEIGHT ^", "(FEET)",
                new ParameterColumn("CAPT", new RadioHeightParameterRow(1)),
                new ParameterColumn("LRRAL", new RadioHeightParameterRow(2)),
                new ParameterColumn("LRRAR", new RadioHeightParameterRow(3)),
                new ParameterColumn("LRRAC", new RadioHeightParameterRow(4))
                //,
                //new ParameterColumn("F/O", new SignedParameterRow(204, 0, 0, 12, 3, 0.0, 0.5, 1))
                ));
            Add(new Parameter("SYNC WORD", "",
                new ParameterColumn("", new SyncWordParameterRow())));
            Add(new Parameter("Raw VERTICAL ACCELERATION", "",
                new ParameterColumn("",
                    new UnsignedParameterRow(2, 0, 0, 12, 1, 0.0, 1.0, 0),
                    new UnsignedParameterRow(34, 0, 0, 12, 1, 0.0, 1.0, 0),
                    new UnsignedParameterRow(66, 0, 0, 12, 1, 0.0, 1.0, 0),
                    new UnsignedParameterRow(98, 0, 0, 12, 1, 0.0, 1.0, 0),
                    new UnsignedParameterRow(130, 0, 0, 12, 1, 0.0, 1.0, 0),
                    new UnsignedParameterRow(162, 0, 0, 12, 1, 0.0, 1.0, 0),
                    new UnsignedParameterRow(194, 0, 0, 12, 1, 0.0, 1.0, 0),
                    new UnsignedParameterRow(226, 0, 0, 12, 1, 0.0, 1.0, 0))));
            Add(new Parameter("VERTICAL ACCELERATION", "(G's)",
                new ParameterColumn("",
                    new UnsignedParameterRow(2, 0, 0, 12, 1, -3.375, 0.00228938, 3),
                    new UnsignedParameterRow(34, 0, 0, 12, 1, -3.375, 0.00228938, 3),
                    new UnsignedParameterRow(66, 0, 0, 12, 1, -3.375, 0.00228938, 3),
                    new UnsignedParameterRow(98, 0, 0, 12, 1, -3.375, 0.00228938, 3),
                    new UnsignedParameterRow(130, 0, 0, 12, 1, -3.375, 0.00228938, 3),
                    new UnsignedParameterRow(162, 0, 0, 12, 1, -3.375, 0.00228938, 3),
                    new UnsignedParameterRow(194, 0, 0, 12, 1, -3.375, 0.00228938, 3),
                    new UnsignedParameterRow(226, 0, 0, 12, 1, -3.375, 0.00228938, 3))));
            Add(new Parameter("Last File Position", "",
                new ParameterColumn("", new FilePosParameterRow())));
            Add(new Parameter("Sync Lost", "",
                new ParameterColumn("", new SyncLostParameterRow())));
            Add(new Parameter("Words in Frame", "",
                new ParameterColumn("", new LastFramePosParameterRow())));

            //New Parameters for version 1.1
            Add(new Parameter("FMC/IRU DATA SOURCE", "",
                new ParameterColumn("", new ZeroOneParameterRow(50, 4, 0, 1, "IRU DATA", "FMC DATA"))));
            Add(new Parameter("Super Frame Number", "",
                new ParameterColumn("", new SuperFrameNumberParameterRow())));
            Add(new Parameter("TRACK ANGLE TRUE", "(DEG)",
                new ParameterColumn("",
                    new SignedParameterRow(237, 1, 0, 12, 3, 0.0, 0.3516525, 1),
                    new SignedParameterRow(237, 3, 0, 12, 3, 0.0, 0.3516525, 1))));
            Add(new Parameter("VHF ^ KEYING", "",
                new ParameterColumn("CENTER", new ZeroOneParameterRow(6, 0, 0, 1, "KEYED", "NOT KEYED")),
                new ParameterColumn("LEFT", new ZeroOneParameterRow(5, 0, 0, 2, "KEYED", "NOT KEYED")),
                new ParameterColumn("RIGHT", new ZeroOneParameterRow(5, 0, 0, 1, "KEYED", "NOT KEYED"))));
            Add(new Parameter("VOR FREQUENCY^", "(MHz)",
                new ParameterColumn("-LEFT", new VORFrequencyRow(4)),
                new ParameterColumn("-RIGHT", new VORFrequencyRow(2))));
            Add(new Parameter("PITCH ANGLE ^", "(DEG)",
                new ParameterColumn("F/O", new SignedParameterRow(205, 0, 0, 12, 3, 0.0, 0.17578, 1)),
                //new ParameterColumn("IRU",
                //    new SignedParameterRow(217, 1, 0, 12, 3, 0.0, 0.17578, 1),
                //    new SignedParameterRow(217, 3, 0, 12, 3, 0.0, 0.17578, 1)),
                new ParameterColumn("CAPT",
                    new SignedParameterRow(36, 0, 0, 12, 3, 0.0, 0.17578, 1),
                    new SignedParameterRow(100, 0, 0, 12, 3, 0.0, 0.17578, 1),
                    new SignedParameterRow(164, 0, 0, 12, 3, 0.0, 0.17578, 1),
                    new SignedParameterRow(228, 0, 0, 12, 3, 0.0, 0.17578, 1))));
            Add(new Parameter("GROUNDSPEED ^", "(KNOTS)",
                new ParameterColumn("CAPT", new BCDParameterRow(94, 0, 0, 12, 2, 0.0, 1.0, 0))
                //,
                //new ParameterColumn("F/O", new BCDParameterRow(207, 0, 0, 12, 2, 0.0, 1.0, 0))
                ));
            Add(new Parameter("TRUE AIRSPEED", "(KT)",
                new ParameterColumn("", new UnsignedParameterRow(212, 0, 0, 12, 3, 0.0, 2.0, 0))));
            Add(new Parameter("BLEED DUCT PRESS ^", "(PSI)",
                new ParameterColumn("- L",
                    new UnsignedParameterRow(125, 1, 0, 12, 3, 0.0, 0.125, 1),
                    new UnsignedParameterRow(125, 3, 0, 12, 3, 0.0, 0.125, 1)),
                new ParameterColumn("- R",
                    new UnsignedParameterRow(125, 2, 0, 12, 3, 0.0, 0.125, 1),
                    new UnsignedParameterRow(125, 4, 0, 12, 3, 0.0, 0.125, 1))));
            Add(new Parameter("ENG ^ACTUAL ^", "(%RPM)",
                new ParameterColumn("N1-,- L", new UnsignedParameterRow(5, 0, 0, 12, 3, 0.0, 0.125, 1)),
                new ParameterColumn("N1-,- R", new UnsignedParameterRow(133, 0, 0, 12, 3, 0.0, 0.125, 1)),
                new ParameterColumn("N2-,- L", new UnsignedParameterRow(6, 0, 0, 12, 3, 0.0, 0.125, 1)),
                new ParameterColumn("N2-,- R", new UnsignedParameterRow(134, 0, 0, 12, 3, 0.0, 0.125, 1)),
                new ParameterColumn("N3-,- L", new UnsignedParameterRow(7, 0, 0, 12, 3, 0.0, 0.125, 1)),
                new ParameterColumn("N3-,- R", new UnsignedParameterRow(135, 0, 0, 12, 3, 0.0, 0.125, 1))));
            Add(new Parameter("N2 CORRECTED TO 2.5 ^", "(% RPM)",
                new ParameterColumn("- L", new UnsignedParameterRow(72, 0, 0, 12, 3, 0.0, 0.125, 1)),
                new ParameterColumn("- R", new UnsignedParameterRow(200, 0, 0, 12, 3, 0.0, 0.125, 1))));
            //Add(new Parameter("DENSITY ^ TANK", "(LB/GAL)",
            //    new ParameterColumn("S", new UnsignedParameterRow(210, 4, 0, 12, 3, 0.0, 0.008, 1)),
            //    new ParameterColumn("R", new UnsignedParameterRow(210, 2, 0, 12, 3, 0.0, 0.008, 1)),
            //    new ParameterColumn("L", new UnsignedParameterRow(210, 1, 0, 12, 3, 0.0, 0.008, 1)),
            //    new ParameterColumn("C", new UnsignedParameterRow(210, 3, 0, 12, 3, 0.0, 0.008, 1))));
            Add(new Parameter("^ TANK LB/KG", "",
                new ParameterColumn("R", new ZeroOneParameterRow(256, 4, 6, 4, "LB", "KG")),
                new ParameterColumn("S", new ZeroOneParameterRow(256, 4, 6, 3, "LB", "KG")),
                new ParameterColumn("C", new ZeroOneParameterRow(256, 4, 6, 2, "LB", "KG")),
                new ParameterColumn("L", new ZeroOneParameterRow(256, 4, 6, 1, "LB", "KG"))));
            Add(new Parameter("BUS AC VOLTS ^", "(VAC)",
                new ParameterColumn("- LEFT", new UnsignedParameterRow(26, 1, 0, 12, 3, 0.0, 0.25, 1)),
                new ParameterColumn("- RIGHT", new UnsignedParameterRow(26, 2, 0, 12, 3, 0.0, 0.25, 1))));
            Add(new Parameter("^ FUEL PUMP ^", "",
                new ParameterColumn("AFT,- L", new ZeroOneParameterRow(206, 1, 0, 2, "NORMAL", "LO PRESS")),
                new ParameterColumn("AFT,- R", new ZeroOneParameterRow(206, 1, 0, 1, "NORMAL", "LO PRESS")),
                new ParameterColumn("C-L,LT", new ZeroOneParameterRow(67, 2, 0, 2, "LIGHT OFF", "LIGHT ON")),
                new ParameterColumn("C-L,PR", new ZeroOneParameterRow(67, 2, 0, 1, "HI PRESS", "LO PRESS")),
                new ParameterColumn("C-R,LT", new ZeroOneParameterRow(195, 2, 0, 2, "LIGHT OFF", "LIGHT ON")),
                new ParameterColumn("C-R,PR", new ZeroOneParameterRow(195, 2, 0, 1, "HI PRESS", "LO PRESS")),
                new ParameterColumn("FWD,", new ZeroOneParameterRow(206, 2, 0, 2, "NORMAL", "LO PRESS"))));
            Add(new Parameter("ENG EGT^", "(DEG C)",
                new ParameterColumn("-LEFT", new UnsignedParameterRow(8, 0, 0, 12, 2, 0.0, 1.0, 0)),
                new ParameterColumn("-RIGHT", new UnsignedParameterRow(136, 0, 0, 12, 2, 0.0, 1.0, 0))));
            Add(new Parameter("ENG EGT RED ^", "",
                new ParameterColumn("- L", new ZeroOneParameterRow(16, 0, 0, 1, "NORMAL", "RECORD")),
                new ParameterColumn("- R", new ZeroOneParameterRow(144, 0, 0, 1, "NORMAL", "RECORD"))));
            Add(new Parameter("ENG DED GEN ^", "",
                new ParameterColumn("- L", new ZeroOneParameterRow(74, 0, 0, 2, "OK", "FAULT")),
                new ParameterColumn("- R", new ZeroOneParameterRow(202, 0, 0, 2, "OK", "FAULT"))));
            Add(new Parameter("ENG EPR COMMAND ^", "(RATIO)",
                new ParameterColumn("- L",
                    new UnsignedParameterRow(18, 1, 0, 12, 3, 0.0, 0.001953125, 2),
                    new UnsignedParameterRow(18, 3, 0, 12, 3, 0.0, 0.001953125, 2)),
                new ParameterColumn("- R",
                    new UnsignedParameterRow(146, 1, 0, 12, 3, 0.0, 0.001953125, 2),
                    new UnsignedParameterRow(146, 3, 0, 12, 3, 0.0, 0.001953125, 2))));
            Add(new Parameter("ENG EPR LIMIT^", "(RATIO)",
                new ParameterColumn("-L",
                    new UnsignedParameterRow(18, 2, 0, 12, 3, 0.0, 0.001953125, 2),
                    new UnsignedParameterRow(18, 4, 0, 12, 3, 0.0, 0.001953125, 2)),
                new ParameterColumn("-R",
                    new UnsignedParameterRow(146, 2, 0, 12, 3, 0.0, 0.001953125, 2),
                    new UnsignedParameterRow(146, 4, 0, 12, 3, 0.0, 0.001953125, 2))));
            Add(new Parameter("ENG EPR-ACTUAL ^", "(RATIO)",
                new ParameterColumn("- L", new UnsignedParameterRow(4, 0, 0, 12, 3, 0.0, 0.001953125, 2)),
                new ParameterColumn("- R", new UnsignedParameterRow(132, 0, 0, 12, 3, 0.0, 0.001953125, 2))));
            Add(new Parameter("EPR BUG DRIVE ^", "(RATIO)",
                new ParameterColumn("LEFT",
                    new UnsignedParameterRow(19, 1, 0, 12, 1, 0.0, 0.0009766, 2),
                    new UnsignedParameterRow(19, 3, 0, 12, 1, 0.0, 0.0009766, 2)),
                new ParameterColumn("RIGHT",
                    new UnsignedParameterRow(147, 1, 0, 12, 1, 0.0, 0.0009766, 2),
                    new UnsignedParameterRow(147, 3, 0, 12, 1, 0.0, 0.0009766, 2))));
            Add(new Parameter("EPR TARGET-FMC", "(RATIO)",
                new ParameterColumn("",
                    new UnsignedParameterRow(19, 2, 0, 12, 3, 0.0, 0.001953125, 3),
                    new UnsignedParameterRow(19, 4, 0, 12, 3, 0.0, 0.001953125, 3))));
            Add(new Parameter("ENG FUEL FLOW ^", "(LBS/HR)",
                new ParameterColumn("- L", new UnsignedParameterRow(12, 0, 0, 12, 3, 0.0, 32.0, 0)),
                new ParameterColumn("- R", new UnsignedParameterRow(140, 0, 0, 12, 3, 0.0, 32.0, 0))));
            Add(new Parameter("ENG LO OIL PRESS ^", "",
                new ParameterColumn("- L", new ZeroOneParameterRow(25, 0, 0, 2, "NORMAL", "LO PRESS")),
                new ParameterColumn("- R", new ZeroOneParameterRow(153, 0, 0, 2, "NORMAL", "LO PRESS"))));
            Add(new Parameter("ENG OIL PRES ^", "(PSI)",
                new ParameterColumn("- L", new UnsignedParameterRow(11, 0, 0, 12, 3, 0.0, 1.0, 0)),
                new ParameterColumn("- R", new UnsignedParameterRow(139, 0, 0, 12, 3, 0.0, 1.0, 0))));
            Add(new Parameter("ENG OIL PRESS RED ^", "",
                new ParameterColumn("- L", new ZeroOneParameterRow(18, 0, 0, 2, "NORMAL", "RECORD")),
                new ParameterColumn("- R", new ZeroOneParameterRow(146, 0, 0, 2, "NORMAL", "RECORD"))));
            Add(new Parameter("ENG OIL QTY ^", "(US PINT)",
                new ParameterColumn("- L", new UnsignedParameterRow(10, 0, 0, 12, 1, 0.0, 0.03125, 1)),
                new ParameterColumn("- R", new UnsignedParameterRow(138, 0, 0, 12, 1, 0.0, 0.03125, 1))));
            Add(new Parameter("ENG OIL TEMP ^", "(DEG C)",
                new ParameterColumn("- L", new UnsignedParameterRow(9, 0, 0, 12, 3, 0.0, 0.5, 1)),
                new ParameterColumn("- R", new UnsignedParameterRow(137, 0, 0, 12, 3, 0.0, 0.5, 1))));
            Add(new Parameter("ENG OIL TEMP RED ^", "",
                new ParameterColumn("- L", new ZeroOneParameterRow(16, 0, 0, 2, "NORMAL", "RECORD")),
                new ParameterColumn("- R", new ZeroOneParameterRow(144, 0, 0, 2, "NORMAL", "RECORD"))));
            Add(new Parameter("ENG ^ RED ^", "",
                new ParameterColumn("N1,- L", new ZeroOneParameterRow(17, 0, 0, 2, "NORMAL", "RECORD")),
                new ParameterColumn("N1,- R", new ZeroOneParameterRow(145, 0, 0, 2, "NORMAL", "RECORD")),
                new ParameterColumn("N2,- L", new ZeroOneParameterRow(17, 0, 0, 1, "NORMAL", "RECORD")),
                new ParameterColumn("N2,- R", new ZeroOneParameterRow(145, 0, 0, 1, "NORMAL", "RECORD")),
                new ParameterColumn("N3,- L", new ZeroOneParameterRow(18, 0, 0, 1, "NORMAL", "RECORD")),
                new ParameterColumn("N3,- R", new ZeroOneParameterRow(146, 0, 0, 1, "NORMAL", "RECORD"))));
            Add(new Parameter("ENG VIBRATION ^", "(SCALAR)",
                new ParameterColumn("- L", new UnsignedParameterRow(17, 0, 0, 12, 4, 0.0, 0.01, 2)),
                new ParameterColumn("- R", new UnsignedParameterRow(145, 0, 0, 12, 4, 0.0, 0.01, 2))));
            Add(new Parameter("ENG OUT RLY ^", "",
                new ParameterColumn("- L", new ZeroOneParameterRow(11, 0, 0, 2, "ENG RUN", "NOT RUN")),
                new ParameterColumn("- R", new ZeroOneParameterRow(139, 0, 0, 2, "ENG RUN", "NOT RUN"))));
            Add(new Parameter("ENGINE OUT (EO) ^", "",
                new ParameterColumn("- L", new ZeroOneParameterRow(75, 0, 0, 11, "FALSE", "TRUE")),
                new ParameterColumn("- R", new ZeroOneParameterRow(203, 0, 0, 11, "FALSE", "TRUE"))));
            Add(new Parameter("FAN INLET TOTAL TEMP ^", "(DEG C)",
                new ParameterColumn("- L", new UnsignedParameterRow(73, 0, 0, 12, 3, 0.0, 0.125, 1)),
                new ParameterColumn("- R", new UnsignedParameterRow(201, 0, 0, 12, 3, 0.0, 0.125, 1))));
            Add(new Parameter("FILTER ^ VIB ^", "(SCALAR)",
                new ParameterColumn("1,- L", new UnsignedParameterRow(14, 0, 0, 12, 4, 0.0, 0.01, 2)),
                new ParameterColumn("1,- R", new UnsignedParameterRow(142, 0, 0, 12, 4, 0.0, 0.01, 2)),
                new ParameterColumn("2,- L", new UnsignedParameterRow(15, 0, 0, 12, 4, 0.0, 0.01, 2)),
                new ParameterColumn("2,- R", new UnsignedParameterRow(143, 0, 0, 12, 4, 0.0, 0.01, 2)),
                new ParameterColumn("3,- L", new UnsignedParameterRow(16, 0, 0, 12, 4, 0.0, 0.01, 2)),
                new ParameterColumn("3,- R", new UnsignedParameterRow(144, 0, 0, 12, 4, 0.0, 0.01, 2))));
            Add(new Parameter("HYD ELEC PUMP OVHT ^", "",
                new ParameterColumn("- L", new ZeroOneParameterRow(89, 2, 0, 2, "NORMAL", "OVHT")),
                new ParameterColumn("- R", new ZeroOneParameterRow(89, 4, 0, 2, "NORMAL", "OVHT"))));
            Add(new Parameter("HYD PRI PUMP OVHT ^", "",
                new ParameterColumn("- LEFT", new ZeroOneParameterRow(211, 1, 0, 1, "NORMAL", "OVHT")),
                new ParameterColumn("- RIGHT", new ZeroOneParameterRow(211, 3, 0, 1, "NORMAL", "OVHT"))));
            Add(new Parameter("HYD PUMP ^ OVHT - CENTER", "",
                new ParameterColumn("1", new ZeroOneParameterRow(211, 2, 0, 1, "NORMAL", "OVHT")),
                new ParameterColumn("2", new ZeroOneParameterRow(211, 4, 0, 1, "NORMAL", "OVHT"))));
            Add(new Parameter("HYD PRES ^", "(PSI)",
                new ParameterColumn("- C",
                    new UnsignedParameterRow(128, 1, 0, 12, 3, 0.0, 4.0, 0),
                    new UnsignedParameterRow(128, 3, 0, 12, 3, 0.0, 4.0, 0)),
                new ParameterColumn("- L",
                    new UnsignedParameterRow(126, 1, 0, 12, 3, 0.0, 4.0, 0),
                    new UnsignedParameterRow(126, 3, 0, 12, 3, 0.0, 4.0, 0)),
                new ParameterColumn("- R",
                    new UnsignedParameterRow(127, 1, 0, 12, 3, 0.0, 4.0, 0),
                    new UnsignedParameterRow(127, 3, 0, 12, 3, 0.0, 4.0, 0))));
            Add(new Parameter("HYD RSVR PRESS ^", "",
                new ParameterColumn("< 17 - C", new ZeroOneParameterRow(113, 3, 0, 1, "NORMAL", "LO PRESS")),
                new ParameterColumn("< 17 - L", new ZeroOneParameterRow(113, 1, 0, 1, "NORMAL", "LO PRESS")),
                new ParameterColumn("< 17 - R", new ZeroOneParameterRow(113, 2, 0, 1, "NORMAL", "LO PRESS")),
                new ParameterColumn("> 55 - C", new ZeroOneParameterRow(113, 3, 0, 2, "NORMAL", "HI PRESS")),
                new ParameterColumn("> 55 - L", new ZeroOneParameterRow(113, 1, 0, 2, "NORMAL", "HI PRESS")),
                new ParameterColumn("> 55 - R", new ZeroOneParameterRow(113, 2, 0, 2, "NORMAL", "HI PRESS"))));
            Add(new Parameter("HYD SYS LO PRESS ^", "",
                new ParameterColumn("- C", new ZeroOneParameterRow(128, 0, 0, 2, "NORMAL", "LO PRESS")),
                new ParameterColumn("- L", new ZeroOneParameterRow(126, 0, 0, 2, "NORMAL", "LO PRESS")),
                new ParameterColumn("- R", new ZeroOneParameterRow(127, 0, 0, 2, "NORMAL", "LO PRESS"))));
            Add(new Parameter("MASTER CAUTION LIGHT", "",
                new ParameterColumn("", new ZeroOneParameterRow(135, 0, 0, 1, "MCL OFF", "MCL ON"))));
            Add(new Parameter("MASTER WARNING ^", "",
                new ParameterColumn("CAPT", new ZeroOneParameterRow(134, 0, 0, 2, "WARN", "NO WARN")),
                new ParameterColumn("F/O", new ZeroOneParameterRow(134, 0, 0, 1, "WARN", "NO WARN"))));
            Add(new Parameter("BARO COR ^", "(inHg)",
                new ParameterColumn("NO. 1", new UnsignedParameterRow(147, 2, 0, 12, 1, 0.0, 0.01, 2)),
                new ParameterColumn("NO. 2", new UnsignedParameterRow(147, 4, 0, 12, 1, 0.0, 0.01, 2))));
            Add(new Parameter("MAIN CARGO DOOR", "",
                new ParameterColumn("", new ZeroOneParameterRow(251, 4, 0, 1, "CLOSED", "OPEN"))));
            Add(new Parameter("FWD ACCESS DR", "",
                new ParameterColumn("", new ZeroOneParameterRow(251, 4, 0, 2, "CLOSED", "OPEN"))));
            Add(new Parameter("TCAS FAILURE", "",
                new ParameterColumn("", new ZeroOneParameterRow(241, 4, 0, 1, "OK", "FAILURE"))));
            Add(new Parameter("TCAS SYSTEM STATUS", "",
                new ParameterColumn("", new ZeroOneParameterRow(244, 4, 0, 1, "OK", "FAILURE"))));
            Add(new Parameter("EICAS COMPUTER", "",
                new ParameterColumn("", new ZeroOneParameterRow(241, 4, 0, 2, "INOP", "OPER"))));
            Add(new Parameter("IAS ^", "",
                new ParameterColumn("FCC L-A-4",
                    new ZeroOneParameterRow(252, 1, 0, 4, "ENGA NOT", "IAS ENGA"),
                    new ZeroOneParameterRow(252, 3, 0, 4, "ENGA NOT", "IAS ENGA")),
                new ParameterColumn("FCC R-A-4", new ZeroOneParameterRow(252, 2, 0, 4, "ENGA NOT", "IAS ENGA")),
                new ParameterColumn("FCC C-A-4", new ZeroOneParameterRow(252, 4, 0, 4, "ENGA NOT", "IAS ENGA"))));
            Add(new Parameter("IAS LIMIT OPER ^", "",
                new ParameterColumn("FCC L-A-4",
                    new ZeroOneParameterRow(129, 1, 0, 11, "ENGA NOT", "VMO ENGA"),
                    new ZeroOneParameterRow(129, 3, 0, 11, "ENGA NOT", "VMO ENGA")),
                new ParameterColumn("FCC R-A-4", new ZeroOneParameterRow(129, 2, 0, 11, "ENGA NOT", "VMO ENGA")),
                new ParameterColumn("FCC C-A-4", new ZeroOneParameterRow(129, 4, 0, 11, "ENGA NOT", "VMO ENGA"))));
            Add(new Parameter("IAS MODE OPER", "",
                new ParameterColumn("", new ZeroOneParameterRow(129, 0, 0, 1, "INOPER", "OPER"))));

            //New Parameters for version 1.2
            Add(new Parameter("MAINTENANCE REQUIRED ^", "",
                new ParameterColumn("- L", new ZeroOneParameterRow(75, 0, 0, 2, "FALSE", "TRUE")),
                new ParameterColumn("- R", new ZeroOneParameterRow(203, 0, 0, 2, "FALSE", "TRUE"))));
            Add(new Parameter("T/O CONFIG FLAPS", "",
                new ParameterColumn("", new ZeroOneParameterRow(235, 0, 0, 2, "NORMAL", "WARNING"))));
            Add(new Parameter("T/O CONFIG PARK BRK", "",
                new ParameterColumn("", new ZeroOneParameterRow(235, 0, 0, 1, "NORMAL", "WARNING"))));
            Add(new Parameter("Raw FLAP HANDLE POSN", "",
                new ParameterColumn("",
                    new UnsignedParameterRow(107, 0, 0, 12, 3, 0.0, 1.0, 0),
                    new UnsignedParameterRow(235, 0, 0, 12, 3, 0.0, 1.0, 0))));
            Add(new Parameter("FLAP HANDLE POSN Voltage", "(V)",
                new ParameterColumn("",
                    new UnsignedParameterRow(107, 0, 0, 12, 3, 0.0, 0.004882813, 3),
                    new UnsignedParameterRow(235, 0, 0, 12, 3, 0.0, 0.004882813, 3))));
            Add(new Parameter("FLAP HANDLE POSN", "(DEG)",
                new ParameterColumn("",
                    new FlapHandlePositionParameterRow(107),
                    new FlapHandlePositionParameterRow(235))));
            Add(new Parameter("AUTOLAND WARN LT ^", "",
                new ParameterColumn("FCC L-A-4",
                    new ZeroOneParameterRow(236, 1, 0, 2, "A/L WAR NOT", "A/L WARN"),
                    new ZeroOneParameterRow(236, 3, 0, 2, "A/L WAR NOT", "A/L WARN")),
                new ParameterColumn("FCC R-A-4", new ZeroOneParameterRow(236, 2, 0, 2, "A/L WAR NOT", "A/L WARN")),
                new ParameterColumn("FCC C-A-4", new ZeroOneParameterRow(236, 4, 0, 2, "A/L WAR NOT", "A/L WARN"))));
            //Add(new Parameter("SPEED SELECTED-AUTO", "(KNOTS)",
            //    new ParameterColumn("", new UnsignedParameterRow(236, 0, 0, 12, 3, 0.0, 0.5, 1))));
            Add(new Parameter("A/P CAUTION ^", "",
                new ParameterColumn("FCC L-A-4",
                    new ZeroOneParameterRow(237, 1, 0, 1, "CAUT'N NOT", "A/P CAUT'N"),
                    new ZeroOneParameterRow(237, 3, 0, 1, "CAUT'N NOT", "A/P CAUT'N")),
                new ParameterColumn("FCC R-A-4", new ZeroOneParameterRow(237, 2, 0, 1, "CAUT'N NOT", "A/P CAUT'N")),
                new ParameterColumn("FCC C-A-4", new ZeroOneParameterRow(237, 4, 0, 1, "CAUT'N NOT", "A/P CAUT'N"))));
            Add(new Parameter("WINDSHEAR CAUTION", "",
                new ParameterColumn("",
                    new ZeroOneParameterRow(91, 0, 0, 2, "NOT TRUE", "TRUE"),
                    new ZeroOneParameterRow(237, 0, 0, 2, "NOT TRUE", "TRUE"))));
            Add(new Parameter("GPWC FAILURE", "",
                new ParameterColumn("", new ZeroOneParameterRow(242, 4, 0, 2, "OK", "FAILURE"))));
            Add(new Parameter("LAND ^ (GREEN) ^", "",
                new ParameterColumn("2,FCC L-A-4",
                    new ZeroOneParameterRow(243, 1, 0, 2, "NOT LAND 2", "LAND 2"),
                    new ZeroOneParameterRow(243, 3, 0, 2, "NOT LAND 2", "LAND 2")),
                new ParameterColumn("2,FCC R-A-4", new ZeroOneParameterRow(243, 2, 0, 2, "NOT LAND 2", "LAND 2")),
                new ParameterColumn("2,FCC C-A-4", new ZeroOneParameterRow(243, 4, 0, 2, "NOT LAND 2", "LAND 2")),
                new ParameterColumn("3,FCC L-A-4",
                    new ZeroOneParameterRow(243, 1, 0, 1, "NOT LAND 3", "LAND 3"),
                    new ZeroOneParameterRow(243, 3, 0, 1, "NOT LAND 3", "LAND 3")),
                new ParameterColumn("3,FCC R-A-4", new ZeroOneParameterRow(243, 2, 0, 1, "NOT LAND 3", "LAND 3")),
                new ParameterColumn("3,FCC C-A-4", new ZeroOneParameterRow(243, 4, 0, 1, "NOT LAND 3", "LAND 3"))));
            Add(new Parameter("Raw CAPT CONT COLUMN POSN", "",
                new ParameterColumn("",
                    new SignedParameterRow(37, 0, 0, 12, 1, 0.0, 1.0, 0),
                    new SignedParameterRow(101, 0, 0, 12, 1, 0.0, 1.0, 0),
                    new SignedParameterRow(165, 0, 0, 12, 1, 0.0, 1.0, 0),
                    new SignedParameterRow(229, 0, 0, 12, 1, 0.0, 1.0, 0))));
            Add(new Parameter("CAPT CONT COLUMN POSN", "(DEG)",
                new ParameterColumn("",
                    new CaptContColumnPosnParameterRow(37),
                    new CaptContColumnPosnParameterRow(101),
                    new CaptContColumnPosnParameterRow(165),
                    new CaptContColumnPosnParameterRow(229))));
            Add(new Parameter("TOTAL PRESSURE", "(mB)",
                new ParameterColumn("", new UnsignedParameterRow(32, 0, 0, 12, 3, 0.0, 2.0, 0))));
            Add(new Parameter("Raw CAPT CONT WHEEL POSN", "",
                new ParameterColumn("",
                    new SignedParameterRow(47, 0, 0, 12, 1, 0.0, 1.0, 0),
                    new SignedParameterRow(111, 0, 0, 12, 1, 0.0, 1.0, 0),
                    new SignedParameterRow(175, 0, 0, 12, 1, 0.0, 1.0, 0),
                    new SignedParameterRow(239, 0, 0, 12, 1, 0.0, 1.0, 0))));
            Add(new Parameter("CAPT CONT WHEEL POSN", "(DEG)",
                new ParameterColumn("",
                    new SignedParameterRow(47, 0, 0, 12, 1, 0.0, 315.0 / 2048, 1),
                    new SignedParameterRow(111, 0, 0, 12, 1, 0.0, 315.0 / 2048, 1),
                    new SignedParameterRow(175, 0, 0, 12, 1, 0.0, 315.0 / 2048, 1),
                    new SignedParameterRow(239, 0, 0, 12, 1, 0.0, 315.0 / 2048, 1))));

            //New Parameters for version 1.3
            Add(new Parameter("AOA HEAT ON ^", "",
                new ParameterColumn("- #1", new ZeroOneParameterRow(217, 1, 0, 2, "AOA OFF #1", "AOA ON #1")),
                new ParameterColumn("- #2", new ZeroOneParameterRow(217, 3, 0, 2, "AOA OFF #2", "AOA ON #2"))));
            Add(new Parameter("AOA PROBE HEAT ^", "",
                new ParameterColumn("- L", new ZeroOneParameterRow(205, 2, 0, 2, "OK", "FAULT")),
                new ParameterColumn("- R", new ZeroOneParameterRow(205, 2, 0, 1, "OK", "FAULT"))));
            //Add(new Parameter("CORRECTED AOA", "(DEG)",
            //    new ParameterColumn("", new SignedParameterRow(210, 0, 0, 12, 3, 0.0, 0.35156, 2))));
            Add(new Parameter("INDICATED AOA", "(DEG)",
                new ParameterColumn("",
                    new SignedParameterRow(123, 0, 0, 12, 3, 0.0, 0.17578125, 1),
                    new SignedParameterRow(251, 0, 0, 12, 3, 0.0, 0.17578125, 1))));
            //Add(new Parameter("INDICATED AOA3", "(DEG)",
            //    new ParameterColumn("",
            //        new SignedParameterRow(11, 0, 0, 12, 3, 0.0, 0.1758, 2),
            //        new SignedParameterRow(43, 0, 0, 12, 3, 0.0, 0.1758, 2))));
            //Add(new Parameter("INDICATED AOA4", "(DEG)",
            //    new ParameterColumn("",
            //        new SignedParameterRow(123, 0, 0, 12, 3, 0.0, 0.1758, 2),
            //        new SignedParameterRow(251, 0, 0, 12, 3, 0.0, 0.1758, 2))));
            //Add(new Parameter("INDICATEDAOA2", "(DEG)",
            //    new ParameterColumn("",
            //        new SignedParameterRow(11, 0, 0, 12, 3, 0.0, 0.176, 2),
            //        new SignedParameterRow(43, 0, 0, 12, 3, 0.0, 0.176, 2))));
            //Add(new Parameter("SPD BRK HDL POSN", "(%)",
            //    new ParameterColumn("",
            //        new UnsignedParameterRow(93, 0, 0, 12, 3, 0.0, 0.125, 2),
            //        new UnsignedParameterRow(221, 0, 0, 12, 3, 0.0, 0.125, 2))));
            //Add(new Parameter("SPD BRK HDL POSN2 ^", "(%)",
            //    new ParameterColumn("FCC L-A-4", 
            //        new UnsignedParameterRow(41, 1, 0, 12, 3, 0.0, 0.125, 2),
            //        new UnsignedParameterRow(105, 1, 0, 12, 3, 0.0, 0.125, 2),
            //        new UnsignedParameterRow(169, 1, 0, 12, 3, 0.0, 0.125, 2),
            //        new UnsignedParameterRow(233, 1, 0, 12, 3, 0.0, 0.125, 2)),
            //    new ParameterColumn("FCC R-A-4", 
            //        new UnsignedParameterRow(41, 2, 0, 12, 3, 0.0, 0.125, 2),
            //        new UnsignedParameterRow(105, 2, 0, 12, 3, 0.0, 0.125, 2),
            //        new UnsignedParameterRow(169, 2, 0, 12, 3, 0.0, 0.125, 2),
            //        new UnsignedParameterRow(233, 2, 0, 12, 3, 0.0, 0.125, 2)),
            //    new ParameterColumn("MCP A-A-2", 
            //        new UnsignedParameterRow(41, 3, 0, 12, 3, 0.0, 0.125, 2),
            //        new UnsignedParameterRow(105, 3, 0, 12, 3, 0.0, 0.125, 2),
            //        new UnsignedParameterRow(169, 3, 0, 12, 3, 0.0, 0.125, 2),
            //        new UnsignedParameterRow(233, 3, 0, 12, 3, 0.0, 0.125, 2)),
            //    new ParameterColumn("FCC C-A-4", 
            //        new UnsignedParameterRow(41, 4, 0, 12, 3, 0.0, 0.125, 2),
            //        new UnsignedParameterRow(105, 4, 0, 12, 3, 0.0, 0.125, 2),
            //        new UnsignedParameterRow(169, 4, 0, 12, 3, 0.0, 0.125, 2),
            //        new UnsignedParameterRow(233, 4, 0, 12, 3, 0.0, 0.125, 2))));
            Add(new Parameter("IDLE THRUST OPER", "",
                new ParameterColumn("", new ZeroOneParameterRow(224, 0, 0, 12, "INOPER", "OPER"))));
            Add(new Parameter("FLT DECK DOOR", "",
                new ParameterColumn("", new ZeroOneParameterRow(251, 3, 0, 1, "CLOSED", "OPEN"))));
            //Add(new Parameter("DOC DEPART ^", "",
            //    new ParameterColumn("MSC", new CharacterParameterRow(256, 3, 1, 8, 1)),
            //    new ParameterColumn("LSC+1", new CharacterParameterRow(256, 3, 2, 8, 1)),
            //    new ParameterColumn("LSC", new CharacterParameterRow(256, 3, 3, 8, 1))));
            //Add(new Parameter("DOC DEST ^", "",
            //    new ParameterColumn("MSC", new CharacterParameterRow(256, 3, 4, 8, 1)),
            //    new ParameterColumn("LSC+1", new CharacterParameterRow(256, 3, 5, 8, 1)),
            //    new ParameterColumn("LSC", new CharacterParameterRow(256, 3, 6, 8, 1))));
            //Add(new Parameter("DOC FLT NUMBER ^", "",
            //    new ParameterColumn("MSC", new CharacterParameterRow(256, 3, 7, 8, 1)),
            //    new ParameterColumn("LSC+2", new CharacterParameterRow(256, 3, 8, 8, 1)),
            //    new ParameterColumn("LSC+1", new CharacterParameterRow(256, 3, 9, 8, 1)),
            //    new ParameterColumn("LSC", new CharacterParameterRow(256, 3, 10, 8, 1))));
            //Add(new Parameter("DOC LEG NUMBER", "",
            //    new ParameterColumn("", new CharacterParameterRow(256, 3, 11, 8, 1))));
            Add(new Parameter("MANUFACTURER CODE", "",
                new ParameterColumn("", new ManufacturerCodeParameterRow())));
            Add(new Parameter("MANDATORY S/W P/N CODE", "",
                new ParameterColumn("", new UnsignedParameterRow(256, 4, 2, 12, 1, 0.0, 1.0, 0))));
            Add(new Parameter("ACMS S/W P/N CODE", "",
                new ParameterColumn("", new UnsignedParameterRow(256, 4, 3, 12, 1, 0.0, 1.0, 0))));
            Add(new Parameter("VENDOR DATABASE CODE", "",
                new ParameterColumn("", new UnsignedParameterRow(256, 4, 4, 12, 1, 0.0, 1.0, 0))));

            //New Parameters for version 1.4
            Add(new Parameter("FLT DIR - PITCH ^", "(DEG)",
                new ParameterColumn("CAPT", new SignedParameterRow(209, 1, 0, 12, 3, 0.0, 0.17578, 1))));
            //new ParameterColumn("F/O", new SignedParameterRow(209, 3, 0, 12, 3, 0.0, 0.17578, 1))));
            Add(new Parameter("FLT DIR - ROLL ^", "(DEG)",
                new ParameterColumn("CAPT", new SignedParameterRow(209, 2, 0, 12, 3, 0.0, 0.35156, 1))));
            //new ParameterColumn("F/O", new SignedParameterRow(209, 4, 0, 12, 3, 0.0, 0.35156, 1))));
            Add(new Parameter("FLT DIR ON^ ^", "",
                new ParameterColumn("-CAPT,MCP A-A-2", new ZeroOneParameterRow(250, 0, 0, 2, "CAPT OFF", "CAPT ON")),
                new ParameterColumn("-CAPT,FCC L-A-4",
                    new ZeroOneParameterRow(252, 1, 0, 3, "CAPT OFF", "CAPT ON"),
                    new ZeroOneParameterRow(252, 3, 0, 3, "CAPT OFF", "CAPT ON")),
                new ParameterColumn("-CAPT,FCC R-A-4", new ZeroOneParameterRow(252, 2, 0, 3, "CAPT OFF", "CAPT ON")),
                new ParameterColumn("-CAPT,FCC C-A-4", new ZeroOneParameterRow(252, 4, 0, 3, "CAPT OFF", "CAPT ON")),
                new ParameterColumn("-F/O,MCP A-A-2", new ZeroOneParameterRow(250, 0, 0, 1, "F/O OFF", "F/O ON")),
                new ParameterColumn("-F/O,FCC L-A-4",
                    new ZeroOneParameterRow(252, 1, 0, 2, "F/O OFF", "F/O ON"),
                    new ZeroOneParameterRow(252, 3, 0, 2, "F/O OFF", "F/O ON")),
                new ParameterColumn("-F/O,FCC R-A-4", new ZeroOneParameterRow(252, 2, 0, 2, "F/O OFF", "F/O ON")),
                new ParameterColumn("-F/O,FCC C-A-4", new ZeroOneParameterRow(252, 4, 0, 2, "F/O OFF", "F/O ON"))));
            Add(new Parameter("FMA FAULT ^ ^", "",
                new ParameterColumn("1 (CWS),FCC L-A-4",
                    new ZeroOneParameterRow(252, 1, 0, 1, "NO MODE FL", "MODE FAIL"),
                    new ZeroOneParameterRow(252, 3, 0, 1, "NO MODE FL", "MODE FAIL")),
                new ParameterColumn("1 (CWS),FCC R-A-4", new ZeroOneParameterRow(252, 2, 0, 1, "NO MODE FL", "MODE FAIL")),
                new ParameterColumn("1 (CWS),FCC C-A-4", new ZeroOneParameterRow(252, 4, 0, 1, "NO MODE FL", "MODE FAIL")),
                new ParameterColumn("2 (PTCH),FCC L-A-4",
                    new ZeroOneParameterRow(129, 1, 0, 7, "NO MODE FL", "MODE FAIL"),
                    new ZeroOneParameterRow(129, 3, 0, 7, "NO MODE FL", "MODE FAIL")),
                new ParameterColumn("2 (PTCH),FCC R-A-4", new ZeroOneParameterRow(129, 2, 0, 7, "NO MODE FL", "MODE FAIL")),
                new ParameterColumn("2 (PTCH),FCC C-A-4", new ZeroOneParameterRow(129, 4, 0, 7, "NO MODE FL", "MODE FAIL")),
                new ParameterColumn("3 (ROLL),FCC L-A-4",
                    new ZeroOneParameterRow(193, 1, 0, 5, "NO MODE FL", "MODE FAIL"),
                    new ZeroOneParameterRow(193, 3, 0, 5, "NO MODE FL", "MODE FAIL")),
                new ParameterColumn("3 (ROLL),FCC R-A-4", new ZeroOneParameterRow(193, 2, 0, 5, "NO MODE FL", "MODE FAIL")),
                new ParameterColumn("3 (ROLL),FCC C-A-4", new ZeroOneParameterRow(193, 4, 0, 5, "NO MODE FL", "MODE FAIL"))));
            Add(new Parameter("ROLL ANGLE ^", "(DEG)",
                new ParameterColumn("F/O", new SignedParameterRow(206, 0, 0, 12, 3, 0.0, 0.35156, 1)),
                //new ParameterColumn("IRU",
                //    new SignedParameterRow(217, 2, 0, 12, 3, 0.0, 0.35156, 1),
                //    new SignedParameterRow(217, 4, 0, 12, 3, 0.0, 0.35156, 1)),
                new ParameterColumn("CAPT",
                    new SignedParameterRow(46, 0, 0, 12, 3, 0.0, 0.35156, 1),
                    new SignedParameterRow(110, 0, 0, 12, 3, 0.0, 0.35156, 1),
                    new SignedParameterRow(174, 0, 0, 12, 3, 0.0, 0.35156, 1),
                    new SignedParameterRow(238, 0, 0, 12, 3, 0.0, 0.35156, 1))));
            Add(new Parameter("ROLL ARM ^", "",
                new ParameterColumn("FCC L-A-4",
                    new ZeroOneParameterRow(212, 1, 0, 2, "NOT ARMED", "ARMED"),
                    new ZeroOneParameterRow(212, 3, 0, 2, "NOT ARMED", "ARMED")),
                new ParameterColumn("FCC R-A-4", new ZeroOneParameterRow(212, 2, 0, 2, "NOT ARMED", "ARMED")),
                new ParameterColumn("FCC C-A-4", new ZeroOneParameterRow(212, 4, 0, 2, "NOT ARMED", "ARMED"))));
            Add(new Parameter("ROLL DISAGREE ^", "",
                new ParameterColumn("CAPT", new ZeroOneParameterRow(114, 4, 0, 2, "NOT", "ALERT")),
                new ParameterColumn("F/O", new ZeroOneParameterRow(114, 4, 0, 1, "NOT", "ALERT"))));
            Add(new Parameter("ROLL ENGAGE DETENT CMD ^", "",
                new ParameterColumn("FCC L-A-4",
                    new ZeroOneParameterRow(213, 1, 0, 1, "NOT ENGAGED", "ENGAGED"),
                    new ZeroOneParameterRow(213, 3, 0, 1, "NOT ENGAGED", "ENGAGED")),
                new ParameterColumn("FCC R-A-4", new ZeroOneParameterRow(213, 2, 0, 1, "NOT ENGAGED", "ENGAGED")),
                new ParameterColumn("FCC C-A-4", new ZeroOneParameterRow(213, 4, 0, 1, "NOT ENGAGED", "ENGAGED"))));
            //Add(new Parameter("ROLL FORCE LINK POSN", "(DEG)",
            //    new ParameterColumn("", new SignedParameterRow(214, 0, 0, 12, 2, 0.0, 0.0, 0))));
            //Add(new Parameter("ROLL SERVO CMD ^", "(DEG)",
            //    new ParameterColumn("FCC L-A-4", 
            //        new SignedParameterRow(213, 1, 0, 12, 2, 0.0, 0.032461, 2),
            //        new SignedParameterRow(213, 3, 0, 12, 2, 0.0, 0.032461, 2)),
            //    new ParameterColumn("FCC R-A-4", new SignedParameterRow(213, 2, 0, 12, 2, 0.0, 0.032461, 2)),
            //    new ParameterColumn("FCC C-A-4", new SignedParameterRow(213, 4, 0, 12, 2, 0.0, 0.032461, 2))));
            Add(new Parameter("ROLL TRIM CMD ^ WING DOWN", "",
                new ParameterColumn("L",
                    new ZeroOneParameterRow(51, 0, 0, 2, "NO TRIM", "TRIM"),
                    new ZeroOneParameterRow(179, 0, 0, 2, "NO TRIM", "TRIM")),
                new ParameterColumn("R",
                    new ZeroOneParameterRow(51, 0, 0, 1, "NO TRIM", "TRIM"),
                    new ZeroOneParameterRow(179, 0, 0, 1, "NO TRIM", "TRIM"))));
            //Add(new Parameter("ROLLOUT ENGAGED HUD", "",
            //    new ParameterColumn("", new ZeroOneParameterRow(45, 4, 0, 3, "TBD", "TBD"))));
            Add(new Parameter("ROLLOUT MODE OPER ^", "",
                new ParameterColumn("FCC L-A-4",
                    new ZeroOneParameterRow(193, 1, 0, 11, "ENGA NOT", "ROLLOUT EN"),
                    new ZeroOneParameterRow(193, 3, 0, 11, "ENGA NOT", "ROLLOUT EN")),
                new ParameterColumn("FCC R-A-4", new ZeroOneParameterRow(193, 2, 0, 11, "ENGA NOT", "ROLLOUT EN")),
                new ParameterColumn("FCC C-A-4", new ZeroOneParameterRow(193, 4, 0, 11, "ENGA NOT", "ROLLOUT EN"))));
            //Add(new Parameter("ROLLOUT WARNING HUD", "",
            //    new ParameterColumn("", new ZeroOneParameterRow(87, 1, 0, 2, "TBD", "TBD"))));

            //New Parameters for version 1.4.1
            Add(new Parameter("COMPAR ENABLE ^", "",
                new ParameterColumn("CAPT", new ZeroOneParameterRow(116, 4, 0, 2, "ENABLE", "DISABLE")),
                new ParameterColumn("F/O", new ZeroOneParameterRow(116, 4, 0, 1, "ENABLE", "DISABLE"))));
            Add(new Parameter("COMPARATOR FAIL ^", "",
                new ParameterColumn("CAPT", new ZeroOneParameterRow(119, 4, 0, 2, "NOT", "FAIL")),
                new ParameterColumn("F/O", new ZeroOneParameterRow(119, 4, 0, 1, "ENABLE", "DISABLE"))));
            Add(new Parameter("CON MODE OPER", "",
                new ParameterColumn("", new ZeroOneParameterRow(224, 0, 0, 9, "INOPER", "OPER"))));
            Add(new Parameter("GROSS WEIGHT", "(LBS)",
                new ParameterColumn("", new UnsignedParameterRow(256, 4, 9, 12, 1, 0.0, 80.0, 0))));
            //Add(new Parameter("ZERO FUEL WEIGHT", "(LBS)",
            //    new ParameterColumn("", new UnsignedParameterRow(256, 4, 10, 12, 1, 0.0, 80.0, 0))));
            Add(new Parameter("HYD GENERATOR", "",
                new ParameterColumn("", new ZeroOneParameterRow(87, 4, 0, 2, "POWERED", "UNPOWER"))));
            Add(new Parameter("STRUT LOOP 1 ^", "",
                new ParameterColumn("- L", new ZeroOneParameterRow(73, 0, 0, 2, "OK", "FAULT")),
                new ParameterColumn("- R", new ZeroOneParameterRow(201, 0, 0, 2, "OK", "FAULT"))));
            Add(new Parameter("ENG OIL FILTER ^", "",
                new ParameterColumn("- L", new ZeroOneParameterRow(26, 0, 0, 2, "NORMAL", "BYPASS")),
                new ParameterColumn("- R", new ZeroOneParameterRow(154, 0, 0, 2, "NORMAL", "BYPASS"))));
            Add(new Parameter("CTR ENTRY DOOR ^", "",
                new ParameterColumn("- L", new ZeroOneParameterRow(90, 2, 0, 2, "CLOSED", "OPEN")),
                new ParameterColumn("- R", new ZeroOneParameterRow(90, 2, 0, 1, "CLOSED", "OPEN"))));
            Add(new Parameter("AUTOTHROTTLE DISC", "",
                new ParameterColumn("", new ZeroOneParameterRow(161, 3, 0, 2, "NORMAL", "DISCONNECT"))));
            Add(new Parameter("GEAR DOORS SYS ^", "",
                new ParameterColumn("1", new ZeroOneParameterRow(156, 3, 0, 1, "CLOSED", "OPEN")),
                new ParameterColumn("2", new ZeroOneParameterRow(156, 3, 0, 2, "CLOSED", "OPEN"))));
            Add(new Parameter("ECS PACK OFF ^", "",
                new ParameterColumn("- L", new ZeroOneParameterRow(113, 4, 0, 2, "ON", "OFF")),
                new ParameterColumn("- R", new ZeroOneParameterRow(113, 4, 0, 1, "ON", "OFF"))));
            //Add(new Parameter("MAIN CARGO DOOR", "",
            //    new ParameterColumn("", new ZeroOneParameterRow(251, 4, 0, 1, "CLOSED", "OPEN"))));
            Add(new Parameter("T.E. FLAP ASYM", "",
                new ParameterColumn("", new ZeroOneParameterRow(184, 4, 0, 1, "NORMAL", "FLAPS ASYM"))));
            Add(new Parameter("HYD ELEV VALVE ^", "",
                new ParameterColumn("- C", new ZeroOneParameterRow(220, 4, 0, 1, "OPEN", "CLOSED")),
                new ParameterColumn("- L", new ZeroOneParameterRow(244, 3, 0, 2, "OPEN", "CLOSED")),
                new ParameterColumn("- R", new ZeroOneParameterRow(244, 4, 0, 2, "OPEN", "CLOSED"))));
            Add(new Parameter("FWD EQUIP SMOKE", "",
                new ParameterColumn("", new ZeroOneParameterRow(27, 0, 0, 1, "NORMAL", "SMOKE"))));
            Add(new Parameter("FIRE EXT SWITCH ^", "",
                new ParameterColumn("- L", new ZeroOneParameterRow(67, 4, 0, 1, "NORMAL", "PULLED")),
                new ParameterColumn("- R", new ZeroOneParameterRow(195, 4, 0, 1, "NORMAL", "PULLED"))));
            Add(new Parameter("A/P T.E. FLAP POSITION ^", "(DEG)",
                new ParameterColumn("FCC L-A-4",
                    new SignedParameterRow(106, 1, 0, 12, 3, 0.0, 0.17578, 1),
                    new SignedParameterRow(234, 1, 0, 12, 3, 0.0, 0.17578, 1)),
                new ParameterColumn("FCC R-A-4",
                    new SignedParameterRow(106, 2, 0, 12, 3, 0.0, 0.17578, 1),
                    new SignedParameterRow(234, 2, 0, 12, 3, 0.0, 0.17578, 1)),
                //new ParameterColumn("MCP A-A-2",
                //    new SignedParameterRow(106, 3, 0, 12, 3, 0.0, 0.17578, 1),
                //    new SignedParameterRow(234, 3, 0, 12, 3, 0.0, 0.17578, 1)),
                new ParameterColumn("FCC C-A-4",
                    new SignedParameterRow(106, 4, 0, 12, 3, 0.0, 0.17578, 1),
                    new SignedParameterRow(234, 4, 0, 12, 3, 0.0, 0.17578, 1))));
            Add(new Parameter("CARGO FIRE SW", "",
                new ParameterColumn("", new ZeroOneParameterRow(205, 3, 0, 1, "NORMAL", "FIRE"))));
            Add(new Parameter("B117 - PRE 97 RULE", "",
                new ParameterColumn("", new ZeroOneParameterRow(256, 4, 8, 1, "0 (POST 97)", "1 (PRE 97)"))));
            Add(new Parameter("B118 - CUSTOMER UNIQUE FRAME", "",
                new ParameterColumn("", new ZeroOneParameterRow(256, 4, 7, 3, "0 (UNIQUE)", "1 (NOT UNIQUE)"))));
            Add(new Parameter("B119 - FRAME SEL MSB", "",
                new ParameterColumn("", new ZeroOneParameterRow(256, 4, 7, 2, "0 (NOT CODED)", "1 (CODED)"))));
            Add(new Parameter("B120 - FRAME SEL LSB", "",
                new ParameterColumn("", new ZeroOneParameterRow(256, 4, 7, 1, "0 (NOT CODED)", "1 (CODED)"))));
            //Add(new Parameter("Raw T.E. FLAP POSITION", "",
            //    new ParameterColumn("",
            //        new SignedParameterRow(44, 0, 0, 12, 3, 0.0, 1.0, 0),
            //        new SignedParameterRow(172, 0, 0, 12, 3, 0.0, 1.0, 0))));
            Add(new Parameter("Pressure Altitude as per 757-3b_1.TXT", "(FEET)",
                new ParameterColumn("", new PressureAltitudeParameterRow())));
            Add(new Parameter("LDG GEAR LEVER", "",
                new ParameterColumn("",
                    new ZeroOneParameterRow(93, 0, 0, 1, "DOWN", "UP/OFF"),
                    new ZeroOneParameterRow(221, 0, 0, 1, "DOWN", "UP/OFF"))));

            //New Parameters for version 1.5
            //Add(new Parameter("^ ACTUAL FUEL QTY", "(LBS)",
            //    new ParameterColumn("C", new UnsignedParameterRow(256, 4, 14, 12, 1, 0.0, 39.99, 2)),
            //    new ParameterColumn("L", new UnsignedParameterRow(256, 4, 12, 12, 1, 0.0, 39.99, 2)),
            //    new ParameterColumn("R", new UnsignedParameterRow(256, 4, 13, 12, 1, 0.0, 39.99, 2)),
            //    new ParameterColumn("S", new UnsignedParameterRow(256, 4, 15, 12, 1, 0.0, 39.99, 2))));
            Add(new Parameter("OVERSPEED", "",
                new ParameterColumn("", new ZeroOneParameterRow(135, 0, 0, 2, "NOT OVRSP", "OVERSPEED"))));
            Add(new Parameter("MACH ENGAGED ^", "",
                new ParameterColumn("FCC L-A-4",
                    new ZeroOneParameterRow(129, 1, 0, 12, "ENGA NOT", "MACH ENGA"),
                    new ZeroOneParameterRow(129, 3, 0, 12, "ENGA NOT", "MACH ENGA")),
                new ParameterColumn("FCC R-A-4", new ZeroOneParameterRow(129, 2, 0, 12, "ENGA NOT", "MACH ENGA")),
                new ParameterColumn("FCC C-A-4", new ZeroOneParameterRow(129, 4, 0, 12, "ENGA NOT", "MACH ENGA"))));
            Add(new Parameter("MACH", "(MACH)",
                new ParameterColumn("", new UnsignedParameterRow(91, 0, 0, 12, 3, 0.0, 0.002, 2))));
            Add(new Parameter("MACH LIMIT OPER ^", "",
                new ParameterColumn("FCC L-A-4",
                    new ZeroOneParameterRow(129, 1, 0, 10, "ENGA NOT", "MMO ENGA"),
                    new ZeroOneParameterRow(129, 3, 0, 10, "ENGA NOT", "MMO ENGA")),
                new ParameterColumn("FCC R-A-4", new ZeroOneParameterRow(129, 2, 0, 10, "ENGA NOT", "MMO ENGA")),
                new ParameterColumn("FCC C-A-4", new ZeroOneParameterRow(129, 4, 0, 10, "ENGA NOT", "MMO ENGA"))));
            Add(new Parameter("MACH MODE OPER", "",
                new ParameterColumn("", new ZeroOneParameterRow(129, 0, 0, 2, "INOPER", "OPER"))));
            Add(new Parameter("MACH SPEED TRIM", "",
                new ParameterColumn("", new ZeroOneParameterRow(210, 4, 0, 1, "OK", "FAULT"))));
            Add(new Parameter("TOTAL AIR TEMP", "(DEG C)",
                new ParameterColumn("", new SignedParameterRow(155, 0, 0, 12, 3, 0.0, 0.25, 1))));
            Add(new Parameter("STATIC AIR TEMP", "(DEG C)",
                new ParameterColumn("", new SignedParameterRow(211, 0, 0, 12, 3, 0.0, 0.25, 1))));
            //Add(new Parameter("STATIC PRESSURE", "(mB)",
            //    new ParameterColumn("", new UnsignedParameterRow(90, 0, 0, 12, 3, 0.0, 2.0, 0))));
            Add(new Parameter("ADC INVALID", "",
                new ParameterColumn("", new ZeroOneParameterRow(246, 3, 0, 1, "ADC OK", "ADC FAIL"))));
            //Add(new Parameter("ASSUMED TEMP", "(DEG C)",
            //    new ParameterColumn("", new SignedParameterRow(81, 3, 0, 12, 4, 0.0, 0.5, 1))));
            Add(new Parameter("WIND SPEED", "(KNOTS)",
                new ParameterColumn("", new UnsignedParameterRow(45, 0, 0, 12, 4, 0.0, 0.5, 1))));
            Add(new Parameter("ADC SELECT ^", "",
                new ParameterColumn("CAPT", new ZeroOneParameterRow(119, 1, 0, 2, "ENABLE", "DISABLE")),
                new ParameterColumn("F/O", new ZeroOneParameterRow(119, 1, 0, 1, "ENABLE", "DISABLE"))));
            Add(new Parameter("ADC SELECT SW-CAPT", "",
                new ParameterColumn("", new ZeroOneParameterRow(97, 0, 0, 1, "ALTN", "NORMAL"))));
            //Add(new Parameter("CONTROL MAX SPEED", "(KT)",
            //    new ParameterColumn("", new UnsignedParameterRow(81, 1, 0, 12, 3, 0.0, 0.5, 1))));
            //Add(new Parameter("CONTROL MIN SPEED", "(KT)",
            //    new ParameterColumn("", new UnsignedParameterRow(81, 2, 0, 12, 3, 0.0, 0.5, 1))));
            //Add(new Parameter("MAX MANEUVER SPEED", "(KT)",
            //    new ParameterColumn("", new UnsignedParameterRow(82, 2, 0, 12, 3, 0.0, 0.5, 1))));
            //Add(new Parameter("MIN MANEUVER SPEED", "(KT)",
            //    new ParameterColumn("", new UnsignedParameterRow(82, 4, 0, 12, 3, 0.0, 0.5, 1))));
            Add(new Parameter("PULL UP", "",
                new ParameterColumn("", new ZeroOneParameterRow(253, 0, 0, 2, "NOT TRUE", "TRUE"))));

            //New Parameters for version 1.6
            Add(new Parameter("A/C TYPE", "",
                new ParameterColumn("", new AircraftTypeParameterRow())));
            Add(new Parameter("WIND DIRECTION TRUE", "(DEG)",
                new ParameterColumn("", new UnsignedParameterRow(173, 0, 0, 12, 3, 0.0, 0.35156, 1))));
            Add(new Parameter("TRUE HEADING CAPT", "(DEG)",
                new ParameterColumn("", new UnsignedParameterRow(64, 0, 0, 12, 3, 0.0, 0.35156, 1))));
            //Add(new Parameter("TRUE HEADING F/O", "(DEG)",
            //    new ParameterColumn("",
            //        new UnsignedParameterRow(27, 1, 0, 12, 3, 0.0, 0.35156, 1),
            //        new UnsignedParameterRow(27, 3, 0, 12, 3, 0.0, 0.35156, 1))));

            //New Parameters for version 1.7
            Add(new Parameter("CORRECTED AOA", "(DEG)",
                new ParameterColumn("", new SignedParameterRow(210, 0, 0, 12, 3, 0.0, 0.17578125, 1))));
            Add(new Parameter("Raw ALTITUDE (1013.25mB) ^", "",
                new ParameterColumn("COARSE", new SignedParameterRow(29, 0, 0, 12, 3, 0.0, 1.0, 0)),
                new ParameterColumn("FINE", new SignedParameterRow(30, 0, 0, 12, 3, 0.0, 1.0, 0))));
            Add(new Parameter("Raw INDICATED AOA", "",
                new ParameterColumn("",
                    new SignedParameterRow(123, 0, 0, 12, 3, 0.0, 1.0, 0),
                    new SignedParameterRow(251, 0, 0, 12, 3, 0.0, 1.0, 0))));
            Add(new Parameter("Raw CORRECTED AOA", "",
                new ParameterColumn("", new SignedParameterRow(210, 0, 0, 12, 3, 0.0, 1.0, 0))));

            //New Parameters for version 1.8
            Add(new Parameter("AILERON POSN-OUTER ^", "(DEG)",
                new ParameterColumn("- L",
                    new SignedParameterRow(51, 0, 0, 12, 3, 0.0, 0.043945, 2),
                    new SignedParameterRow(115, 0, 0, 12, 3, 0.0, 0.043945, 2),
                    new SignedParameterRow(179, 0, 0, 12, 3, 0.0, 0.043945, 2),
                    new SignedParameterRow(243, 0, 0, 12, 3, 0.0, 0.043945, 2)),
                new ParameterColumn("- R",
                    new SignedParameterRow(52, 0, 0, 12, 3, 0.0, 0.043945, 2),
                    new SignedParameterRow(116, 0, 0, 12, 3, 0.0, 0.043945, 2),
                    new SignedParameterRow(180, 0, 0, 12, 3, 0.0, 0.043945, 2),
                    new SignedParameterRow(244, 0, 0, 12, 3, 0.0, 0.043945, 2))));
            Add(new Parameter("STAB POSITION SYNCHRO", "(DEG)",
                new ParameterColumn("", new SignedParameterRow(245, 0, 0, 12, 3, -3.85, 0.07, 1))));
            Add(new Parameter("Raw STAB POSITION SYNCHRO", "(DEG)",
                new ParameterColumn("", new SignedParameterRow(245, 0, 0, 12, 3, 0.0, 1.0, 0))));
            Add(new Parameter("TERRAIN OVERRIDE", "",
                new ParameterColumn("", new ZeroOneParameterRow(245, 0, 0, 2, "NO INHIBIT", "INHIBIT"))));
            Add(new Parameter("RUDDER PEDAL POSITION", "(DEG)",
                new ParameterColumn("",
                    new SignedParameterRow(57, 0, 0, 12, 1, 0.0, -0.026, 1),
                    new SignedParameterRow(121, 0, 0, 12, 1, 0.0, -0.026, 1),
                    new SignedParameterRow(185, 0, 0, 12, 1, 0.0, -0.026, 1),
                    new SignedParameterRow(249, 0, 0, 12, 1, 0.0, -0.026, 1))));
            Add(new Parameter("Raw RUDDER PEDAL POSITION", "(DEG)",
                new ParameterColumn("",
                    new SignedParameterRow(57, 0, 0, 12, 1, 0.0, 1.0, 0),
                    new SignedParameterRow(121, 0, 0, 12, 1, 0.0, 1.0, 0),
                    new SignedParameterRow(185, 0, 0, 12, 1, 0.0, 1.0, 0),
                    new SignedParameterRow(249, 0, 0, 12, 1, 0.0, 1.0, 0))));
            Add(new Parameter("RUDDER POSITION", "(DEG)",
                new ParameterColumn("",
                    new SignedParameterRow(58, 0, 0, 12, 3, 0.0, 0.08789, 2),
                    new SignedParameterRow(122, 0, 0, 12, 3, 0.0, 0.08789, 2),
                    new SignedParameterRow(186, 0, 0, 12, 3, 0.0, 0.08789, 2),
                    new SignedParameterRow(250, 0, 0, 12, 3, 0.0, 0.08789, 2))));
            Add(new Parameter("G/S MODE OPER ^", "",
                new ParameterColumn("FCC L-A-4",
                    new ZeroOneParameterRow(252, 1, 0, 12, "ENGA NOT", "G/S ENGA"),
                    new ZeroOneParameterRow(252, 3, 0, 12, "ENGA NOT", "G/S ENGA")),
                new ParameterColumn("FCC R-A-4", new ZeroOneParameterRow(252, 2, 0, 12, "ENGA NOT", "G/S ENGA")),
                new ParameterColumn("FCC C-A-4", new ZeroOneParameterRow(252, 4, 0, 12, "ENGA NOT", "G/S ENGA"))));
            Add(new Parameter("T/O MODE OPER-P ^", "",
                new ParameterColumn("FCC L-A-4",
                    new ZeroOneParameterRow(252, 1, 0, 9, "ENGA NOT", "P T/O ENGA"),
                    new ZeroOneParameterRow(252, 3, 0, 9, "ENGA NOT", "P T/O ENGA")),
                new ParameterColumn("FCC R-A-4", new ZeroOneParameterRow(252, 2, 0, 9, "ENGA NOT", "P T/O ENGA")),
                new ParameterColumn("FCC C-A-4", new ZeroOneParameterRow(252, 4, 0, 9, "ENGA NOT", "P T/O ENGA"))));
            Add(new Parameter("ALT HOLD MODE OPER ^", "",
                new ParameterColumn("FCC L-A-4",
                    new ZeroOneParameterRow(252, 1, 0, 8, "ENGA NOT", "ALT HLD EN"),
                    new ZeroOneParameterRow(252, 3, 0, 8, "ENGA NOT", "ALT HLD EN")),
                new ParameterColumn("FCC R-A-4", new ZeroOneParameterRow(252, 2, 0, 8, "ENGA NOT", "ALT HLD EN")),
                new ParameterColumn("FCC C-A-4", new ZeroOneParameterRow(252, 4, 0, 8, "ENGA NOT", "ALT HLD EN"))));
            Add(new Parameter("V/S MODE ^", "",
                new ParameterColumn("FCC L-A-4",
                    new ZeroOneParameterRow(252, 1, 0, 7, "ENGA NOT", "V/S ENGA"),
                    new ZeroOneParameterRow(252, 3, 0, 7, "ENGA NOT", "V/S ENGA")),
                new ParameterColumn("FCC R-A-4", new ZeroOneParameterRow(252, 2, 0, 7, "ENGA NOT", "V/S ENGA")),
                new ParameterColumn("FCC C-A-4", new ZeroOneParameterRow(252, 4, 0, 7, "ENGA NOT", "V/S ENGA"))));
            Add(new Parameter("V NAV MODE OPER ^", "",
                new ParameterColumn("FCC L-A-4",
                    new ZeroOneParameterRow(252, 1, 0, 6, "ENGA NOT", "VNAV ENG"),
                    new ZeroOneParameterRow(252, 3, 0, 6, "ENGA NOT", "VNAV ENG")),
                new ParameterColumn("FCC R-A-4", new ZeroOneParameterRow(252, 2, 0, 6, "ENGA NOT", "VNAV ENG")),
                new ParameterColumn("FCC C-A-4", new ZeroOneParameterRow(252, 4, 0, 6, "ENGA NOT", "VNAV ENG"))));
            Add(new Parameter("FL CH MODE OPER ^", "",
                new ParameterColumn("FCC L-A-4",
                    new ZeroOneParameterRow(252, 1, 0, 5, "INOPER", "OPER"),
                    new ZeroOneParameterRow(252, 3, 0, 5, "INOPER", "OPER")),
                new ParameterColumn("FCC R-A-4", new ZeroOneParameterRow(252, 2, 0, 5, "INOPER", "OPER")),
                new ParameterColumn("FCC C-A-4", new ZeroOneParameterRow(252, 4, 0, 5, "INOPER", "OPER"))));
            Add(new Parameter("SINK RATE", "",
                new ParameterColumn("", new ZeroOneParameterRow(253, 0, 0, 1, "NOT TRUE", "TRUE"))));

            //New Parameters for version 1.9
            Add(new Parameter("FLEET IDENT", "",
                new ParameterColumn("", new UnsignedParameterRow(256, 3, 15, 4, 1, 0.0, 1.0, 0))));
            Add(new Parameter("A/C NUMBER", "",
                new ParameterColumn("", new UnsignedParameterRow(256, 3, 16, 8, 1, 0.0, 1.0, 0))));
            Add(new Parameter("ENGINE IDENT", "",
                new ParameterColumn("", new UnsignedParameterRow(255, 4, 1, 12, 1, 0.0, 1.0, 0))));
            Add(new Parameter("EICAS ^ PART NUM", "",
                new ParameterColumn("OPC", new EICASOPCParameterRow()),
                new ParameterColumn("OPS", new EICASOPSParameterRow())));
            Add(new Parameter("Raw EICAS ^ PART NUM ^", "",
                new ParameterColumn("OPC,LSB", new UnsignedParameterRow(255, 4, 4, 6, 1, 0.0, 1.0, 0)),
                new ParameterColumn("OPC,MSB", new UnsignedParameterRow(255, 4, 3, 12, 1, 0.0, 1.0, 0)),
                new ParameterColumn("OPS,LSB", new UnsignedParameterRow(255, 4, 4, 12, 7, 0.0, 1.0, 0)),
                new ParameterColumn("OPS,MSB", new UnsignedParameterRow(255, 4, 2, 12, 1, 0.0, 1.0, 0))));
            Add(new Parameter("EICAS SELECT SW", "",
                new ParameterColumn("", new ZeroOneParameterRow(161, 0, 0, 1, "RIGHT", "LEFT"))));

            //New Parameters for version 1.10
            Add(new Parameter("A/P CMD ^ ENGA ^", "",
                new ParameterColumn("C,FCC L-A-4", new ZeroOneParameterRow(33, 1, 0, 1, "ENGA NOT", "CMD C ENGA")),
                new ParameterColumn("C,FCC R-A-4", new ZeroOneParameterRow(33, 2, 0, 1, "ENGA NOT", "CMD C ENGA")),
                new ParameterColumn("C,MCP A-A-2", new ZeroOneParameterRow(33, 3, 0, 1, "ENGA NOT", "CMD C ENGA")),
                new ParameterColumn("C,FCC C-A-4", new ZeroOneParameterRow(33, 4, 0, 1, "ENGA NOT", "CMD C ENGA")),
                new ParameterColumn("L,FCC L-A-4", new ZeroOneParameterRow(190, 1, 0, 1, "ENGA NOT", "CMD L ENGA")),
                new ParameterColumn("L,FCC R-A-4", new ZeroOneParameterRow(190, 2, 0, 1, "ENGA NOT", "CMD L ENGA")),
                new ParameterColumn("L,MCP A-A-2", new ZeroOneParameterRow(190, 3, 0, 1, "ENGA NOT", "CMD L ENGA")),
                new ParameterColumn("L,FCC C-A-4", new ZeroOneParameterRow(190, 4, 0, 1, "ENGA NOT", "CMD L ENGA")),
                new ParameterColumn("R,FCC L-A-4", new ZeroOneParameterRow(33, 1, 0, 2, "ENGA NOT", "CMD R ENGA")),
                new ParameterColumn("R,FCC R-A-4", new ZeroOneParameterRow(33, 2, 0, 2, "ENGA NOT", "CMD R ENGA")),
                new ParameterColumn("R,MCP A-A-2", new ZeroOneParameterRow(33, 3, 0, 2, "ENGA NOT", "CMD R ENGA")),
                new ParameterColumn("R,FCC C-A-4", new ZeroOneParameterRow(33, 4, 0, 2, "ENGA NOT", "CMD R ENGA"))));
            Add(new Parameter("A/P CWS ^ ENGA ^", "",
                new ParameterColumn("C,FCC L-A-4", new ZeroOneParameterRow(190, 1, 0, 2, "ENGA NOT", "CWS C ENGA")),
                new ParameterColumn("C,FCC R-A-4", new ZeroOneParameterRow(190, 2, 0, 2, "ENGA NOT", "CWS C ENGA")),
                new ParameterColumn("C,MCP A-A-2", new ZeroOneParameterRow(190, 3, 0, 2, "ENGA NOT", "CWS C ENGA")),
                new ParameterColumn("C,FCC C-A-4", new ZeroOneParameterRow(190, 4, 0, 2, "ENGA NOT", "CWS C ENGA")),
                new ParameterColumn("L,FCC L-A-4", new ZeroOneParameterRow(189, 1, 0, 2, "ENGA NOT", "CWS L ENGA")),
                new ParameterColumn("L,FCC R-A-4", new ZeroOneParameterRow(189, 2, 0, 2, "ENGA NOT", "CWS L ENGA")),
                new ParameterColumn("L,MCP A-A-2", new ZeroOneParameterRow(189, 3, 0, 2, "ENGA NOT", "CWS L ENGA")),
                new ParameterColumn("L,FCC C-A-4", new ZeroOneParameterRow(189, 4, 0, 2, "ENGA NOT", "CWS L ENGA")),
                new ParameterColumn("R,FCC L-A-4", new ZeroOneParameterRow(189, 1, 0, 1, "ENGA NOT", "CWS R ENGA")),
                new ParameterColumn("R,FCC R-A-4", new ZeroOneParameterRow(189, 2, 0, 1, "ENGA NOT", "CWS R ENGA")),
                new ParameterColumn("R,MCP A-A-2", new ZeroOneParameterRow(189, 3, 0, 1, "ENGA NOT", "CWS R ENGA")),
                new ParameterColumn("R,FCC C-A-4", new ZeroOneParameterRow(189, 4, 0, 1, "ENGA NOT", "CWS R ENGA"))));
            Add(new Parameter("A/P ENGAGE DETENT ^", "",
                new ParameterColumn("FCC L-A-4",
                    new ZeroOneParameterRow(124, 1, 0, 1, "NOT IN CTL", "A/P IN CTL"),
                    new ZeroOneParameterRow(124, 3, 0, 1, "NOT IN CTL", "A/P IN CTL")),
                new ParameterColumn("FCC R-A-4", new ZeroOneParameterRow(124, 2, 0, 1, "NOT IN CTL", "A/P IN CTL")),
                new ParameterColumn("FCC C-A-4", new ZeroOneParameterRow(124, 4, 0, 1, "NOT IN CTL", "A/P IN CTL"))));
            //Add(new Parameter("A/P SPD BRK HDL POSN", "(%)",
            //    new ParameterColumn("",
            //        new UnsignedParameterRow(93, 1, 0, 12, 3, 0.0, 0.125, 1),
            //        new UnsignedParameterRow(93, 2, 0, 12, 3, 0.0, 0.125, 1),
            //        new UnsignedParameterRow(93, 4, 0, 12, 3, 0.0, 0.125, 1),
            //        new UnsignedParameterRow(221, 1, 0, 12, 3, 0.0, 0.125, 1),
            //        new UnsignedParameterRow(221, 2, 0, 12, 3, 0.0, 0.125, 1),
            //        new UnsignedParameterRow(221, 4, 0, 12, 3, 0.0, 0.125, 1))));
            Add(new Parameter("A/P WARN-2 ^", "",
                new ParameterColumn("BAT", new ZeroOneParameterRow(29, 0, 0, 2, "NORMAL", "A/P DISC")),
                new ParameterColumn("NORM", new ZeroOneParameterRow(29, 0, 0, 1, "NORMAL", "A/P DISC"))));
            Add(new Parameter("A/P WARNING ^", "",
                new ParameterColumn("FCC L-A-4",
                    new ZeroOneParameterRow(236, 1, 0, 1, "WARN NOT", "A/P WARN"),
                    new ZeroOneParameterRow(236, 3, 0, 1, "WARN NOT", "A/P WARN")),
                new ParameterColumn("FCC R-A-4", new ZeroOneParameterRow(236, 2, 0, 1, "WARN NOT", "A/P WARN")),
                new ParameterColumn("FCC C-A-4", new ZeroOneParameterRow(236, 4, 0, 1, "WARN NOT", "A/P WARN"))));
            Add(new Parameter("ALTITUDE REPORTING", "",
                new ParameterColumn("", new ZeroOneParameterRow(225, 0, 0, 1, "ON", "OFF"))));
            Add(new Parameter("AUTOPILOT ENGAGED HUD", "",
                new ParameterColumn("", new ZeroOneParameterRow(153, 1, 0, 1, "NOT SET", "SET"))));
            Add(new Parameter("AUTOTHROTTLE ENGD HUD", "",
                new ParameterColumn("", new ZeroOneParameterRow(153, 3, 0, 1, "NOT SET", "SET"))));
            Add(new Parameter("ENG THROTTLE ^", "",
                new ParameterColumn("- L", new ZeroOneParameterRow(74, 0, 0, 1, "MAXIMUM", "NOT MAX")),
                new ParameterColumn("- R", new ZeroOneParameterRow(202, 0, 0, 1, "MAXIMUM", "NOT MAX"))));
            Add(new Parameter("SPI", "",
                new ParameterColumn("", new ZeroOneParameterRow(225, 0, 0, 2, "IDENT OFF", "IDENT ON"))));
            Add(new Parameter("THR LVR ANG / EQUIV PLA^", "(DEG)",
                new ParameterColumn("-L", new UnsignedParameterRow(3, 0, 0, 12, 3, 0.0, 0.17578125, 1)),
                new ParameterColumn("-R", new UnsignedParameterRow(131, 0, 0, 12, 3, 0.0, 0.17578125, 1))));
            Add(new Parameter("Raw THR LVR ANG / EQUIV PLA^", "",
                new ParameterColumn("-L", new UnsignedParameterRow(3, 0, 0, 12, 3, 0.0, 1.0, 0)),
                new ParameterColumn("-R", new UnsignedParameterRow(131, 0, 0, 12, 3, 0.0, 1.0, 0))));
            Add(new Parameter("THROTTLE HLD ANNUN", "",
                new ParameterColumn("", new ZeroOneParameterRow(132, 0, 0, 2, "NO HOLD", "HOLD"))));
            Add(new Parameter("THRUST MODE OPER", "",
                new ParameterColumn("", new ZeroOneParameterRow(129, 0, 0, 3, "INOPER", "OPER"))));
            Add(new Parameter("THRUST REV POSN'N ^", "(% DEP)",
                new ParameterColumn("- L", new SignedParameterRow(22, 0, 0, 12, 3, 0.0, 0.25, 1)),
                new ParameterColumn("- R", new SignedParameterRow(150, 0, 0, 12, 3, 0.0, 0.25, 1))));
        }

        public int IndexOf(string s)
        {
            Parameter parameter = new Parameter(s, "");
            return IndexOf(parameter);
        }
    }

    //This class allows the input file to be read in units of 128 byte pages.
    public class PageFileStream
    {
        private const int blockLength = 0x20000;

        private FileStream inputFile = null;
        private int inputFileOffset = 0;
        private int inputFileStart = 0;
        private int inputFileLength = 0;
        private int inputFilePos = 0;

        public PageFileStream(string fileName)
        {
            inputFile = new FileStream(fileName, FileMode.Open, FileAccess.Read);
            int fl = (int)inputFile.Length;
            bool finished = false;
            //Search through each pair of 64KB blocks for the earliest recorded data 
            //and find out how long the data is not including the text header at the 
            //beginning of the file.
            for (int fp = fl - blockLength; (fp >= 0) && (!finished); fp -= blockLength)
            {
                inputFile.Seek(fp, SeekOrigin.Begin);
                byte[] headerBytes = new byte[2];
                inputFile.Read(headerBytes, 0, headerBytes.Length);
                int headerWord = (headerBytes[1] << 8) | headerBytes[0];
                switch (headerWord)
                {
                    case 0xFE6B:
                        //This is a pair of 64KB blocks containing valid data.
                        inputFileOffset = fp;
                        break;
                    case 0xFFFF:
                        //This is the pair of blank blocks which is left erased and ready to 
                        //be used when the current pair of blocks is full so the earliest 
                        //recorded data is the next pair of 64KB blocks.
                        inputFileOffset = fp;
                        inputFileStart = fp + blockLength;
                        break;
                    default:
                        //This is invalid data so we must be looking through the text header 
                        //at the beginning of the file.
                        finished = true;
                        break;
                }
            }
            if (inputFileStart >= fl)
                inputFileStart = inputFileOffset;
            //Calculate the start point and length of the data in units of 128 byte pages.
            inputFileStart = (inputFileStart - inputFileOffset) >> 7;
            inputFileLength = (fl - inputFileOffset) >> 7;
            Seek(0);
        }

        public int Length
        {
            get
            {
                return inputFileLength - (blockLength >> 7);
            }
        }

        public int BytePos(int fp)
        {
            //Calculate the byte file offset of a file offset measured in units of 128 byte 
            //pages. Offset 0 is the earliest recorded data. The recorded data wraps around 
            //to the beginning of the file as in a standard ring buffer.
            int pagePos = fp + inputFileStart;
            if (pagePos >= inputFileLength)
                pagePos -= inputFileLength;
            return ((pagePos << 7) + inputFileOffset);
        }

        public void Seek(int fp)
        {
            //Seek in to the file in units of 128 byte pages.
            inputFile.Seek(BytePos(fp), SeekOrigin.Begin);
            inputFilePos = fp;
        }

        public byte[] ReadPage()
        {
            //Read a single 128 byte page.
            byte[] page = new byte[128];
            inputFile.Read(page, 0, page.Length);
            if ((++inputFilePos + inputFileStart) == inputFileLength)
                Seek(inputFilePos);
            return page;
        }

        public void Close()
        {
            inputFile.Close();
        }
    }

    abstract class HuffmanCodeNode
    {
        public bool IsLeaf
        {
            get
            {
                return this is HuffmanCodeLeafNode;
            }
        }
    }

    //This class is for interior (non leaf) nodes of the Huffman tree.
    class HuffmanCodeInteriorNode : HuffmanCodeNode
    {
        private HuffmanCodeNode[] child = null;

        public HuffmanCodeInteriorNode()
        {
            child = new HuffmanCodeNode[2];
            for (int i = 0; i < child.Length; i++)
                child[i] = null;
        }

        public HuffmanCodeNode GetChild(int i)
        {
            return child[i];
        }

        //Add Huffman codes and values (referred to as differences here) to the Huffman tree.
        //The Huffman codes have the form pppppxxxxx in binary.
        //The p bits are from prefix which is a string representation of a binary number. 
        //The x bits are related to the differences. There are a total of numBits x bits.
        //A non-negative differences is considered as a 12 bit signed integer, the first x bit 
        //    is the sign of the integer. The other x bits are a binary representation of 
        //    the absolute value of the integer. 
        //A difference of -1 represents a loss of synchronisation and the end of a segment of 
        //    compressed data.
        public void AddHuffmanCodesForPrefix(string prefix, int startDifference, int numBits)
        {
            //Add the prefix to the Huffman tree.
            HuffmanCodeNode huffmanCodeNode = this;
            for (int i = 0; i < prefix.Length; i++)
            {
                int bit = int.Parse(prefix[i].ToString());
                HuffmanCodeNode nextHuffmanCodeNode = ((HuffmanCodeInteriorNode)huffmanCodeNode).child[bit];
                if (nextHuffmanCodeNode == null)
                {
                    if ((numBits == 0) && (i == prefix.Length - 1))
                    {
                        ((HuffmanCodeInteriorNode)huffmanCodeNode).child[bit] = new HuffmanCodeLeafNode(startDifference);
                        return;
                    }
                    else
                    {
                        nextHuffmanCodeNode = new HuffmanCodeInteriorNode();
                        ((HuffmanCodeInteriorNode)huffmanCodeNode).child[bit] = nextHuffmanCodeNode;
                    }
                }
                huffmanCodeNode = nextHuffmanCodeNode;
            }
            //Add each difference to the Huffman tree, starting with startDifference.
            Stack<HuffmanCodeNode> huffmanCodeNodeStack = new Stack<HuffmanCodeNode>();
            int difference = startDifference;
            while (true)
            {
                bool createdHuffmanCodeNode = false;
                for (int i = 0; i < ((HuffmanCodeInteriorNode)huffmanCodeNode).child.Length; i++)
                {
                    HuffmanCodeNode nextHuffmanCodeNode = ((HuffmanCodeInteriorNode)huffmanCodeNode).child[i];
                    if (nextHuffmanCodeNode == null)
                    {
                        if (huffmanCodeNodeStack.Count < numBits - 1)
                        {
                            nextHuffmanCodeNode = new HuffmanCodeInteriorNode();
                            ((HuffmanCodeInteriorNode)huffmanCodeNode).child[i] = nextHuffmanCodeNode;
                            huffmanCodeNodeStack.Push(huffmanCodeNode);
                            huffmanCodeNode = nextHuffmanCodeNode;
                        }
                        else
                        {
                            ((HuffmanCodeInteriorNode)huffmanCodeNode).child[i] = new HuffmanCodeLeafNode(difference);
                            if (difference < 0x800)
                                difference++;
                            else
                                difference--;
                        }
                        createdHuffmanCodeNode = true;
                        break;
                    }
                }
                if (!createdHuffmanCodeNode)
                {
                    if (huffmanCodeNodeStack.Count < 1)
                        break;
                    huffmanCodeNode = huffmanCodeNodeStack.Pop();
                    if (huffmanCodeNodeStack.Count < 1)
                        difference = 0x1000 - startDifference;
                }
            }
        }
    }

    class HuffmanCodeLeafNode : HuffmanCodeNode
    {
        private int difference = 0;

        public HuffmanCodeLeafNode(int aDifference)
        {
            difference = aDifference;
        }

        public int Difference
        {
            get
            {
                return difference;
            }
        }
    }


    //The following class holds the current state of one of the two independent flight data streams.

    //Information about the format in which the FDR records the data can be found in the post 
    //at http://forums.randi.org/showpost.php?p=2022420&postcount=85 and in figure 4.2-2 of 
    //the document http://www.asc.gov.tw/author_files/ASC-TRT-99-007.pdf

    //Flight Data Stream 0 consists of the first, third, fifth and so on blocks of 512 pages from 
    //the PageFileStream.

    //Flight Data Stream 1 consists of the second, fourth, sixth and so on blocks of 512 pages from 
    //the PageFileStream.

    //The first 2 pages from each block of 512 pages are header pages that also contain Bad Page 
    //Maps. This program ignores these pages.

    //The words within the other pages in the figure are 16 bit words stored Least Significant Byte 
    //first and the Hamming code & page parity occupy the last 11 bits of each page. Within each 
    //16 bit word, the most significant bit is the first bit in the bit stream. Some pages are 
    //blank consisting entirely of 0xFFFF words and need to be skipped. The Hamming code and page 
    //parity are ignored by this program. My AAL77 Hamming code and page parity checker program 
    //does read them however.

    //Data is recorded by the FDR in frames separated by the 16 bit frame marker word 0xFEFE. A 
    //frame consists of 4 subframes of 256 12 bit words. A subframe consists of 1 second of data.
    //The FDR does not record the first 12 bit word of each subframe since they are sync words 
    //and are always the same. Therefore a complete frame is stored as 1020 * 12 bit words. The 
    //subframes are numbered 1 to 4 and appear in that order in each frame.

    //The frames are recorded in a compressed form using Huffman coding. At the beginning of each 
    //section of compressed data within a flight data stream and periodically every 75 frames, a
    //baseline frame is recorded that consists of the Huffman codes of each of the 1020 * 12 bit 
    //words. Each baseline frame is preceded with the bits 1000 and a 16 bit frame counter.

    //The other frames are recorded by calculating the difference between each of the 1020 * 12 bit
    //words in this frame and the one before it in this flight data stream. The Huffman codes of 
    //these differences are recorded for those frames. Each of these frames are preceded with a 
    // 0 bit.

    //Except for the baseline frame at the beginning of each section of compressed data in a flight
    //data stream, the baseline frames are additional copies of the current frame, i.e. the 
    //baseline frames need to not appear in the decoded output, to avoid 2 copies of the same frame
    //of data appearing. This program does not output the first baseline frame at the beginning of 
    //each section of compressed data, so that adds up to 8 seconds of data at the beginning of 
    //each section of compressed data that is not decoded.

    //Frames are alternately stored in each of the flight data streams so one flight data stream 
    //will consist of the first, third, fifth and so on frames of data and the other flight data
    //stream will have the second, fourth, sixth and so on frames of data. A frame counter is 
    //recorded along with each baseline frame that makes it possible to determine which flight data
    //stream contains the first frame of data.

    //A special Huffman code is used to mark the loss of synchronisation and the subsequent end of 
    //the section of compressed data. This can occur at any point within the frame which is why the
    //last frame of data within a section of compressed data is less than 1020 * 12 bit words.

    //In between the sections of compressed data, up to 4 subframes of uncompressed data is 
    //generated in the file each time the FDR is started up which I believe happens when the 
    //engines are started. My AAL77 FDR partial decoder program decodes the uncompressed data.

    class FlightDataStream
    {
        enum FrameStates { StartState, GetFrameType, GetCounter, DecompressFrame, WaitUntilEnd };

        private int[] frame = new int[1020];
        private byte[] page = null;
        private Main main = null;
        private HuffmanCodeNode huffmanCodeTree = null;
        private FrameStates frameState = FrameStates.StartState;
        private int numFlightDataStreams = 0;
        private int subFrameNumber = 0;
        private int superFrameNumber = 0;
        private int counter = -1;
        private int lastFramePos = 0;
        private int bitPos = 0;
        private int pageNum = 0;
        private int filePos = 0;
        private int lastWordPos = -1;
        private int w = 0;
        private bool syncLost = false;
        private bool endOfData = false;
        private bool baseLineFrame = false;
        private bool badFrame = false;

        public FlightDataStream(Main aMain, HuffmanCodeNode aHuffmanCodeTree, int flightDataStreamNumber, int aNumFlightDataStreams)
        {
            main = aMain;
            huffmanCodeTree = aHuffmanCodeTree;
            numFlightDataStreams = aNumFlightDataStreams;
            for (int i = 0; i < frame.Length; i++)
                frame[i] = 0;
            pageNum = (flightDataStreamNumber << 9) + 2;
        }

        public int[] Frame
        {
            get
            {
                return frame;
            }
        }

        public int SubFrameNumber
        {
            get
            {
                return subFrameNumber;
            }
        }

        public int SuperFrameNumber
        {
            get
            {
                return superFrameNumber;
            }
        }

        public int Counter
        {
            get
            {
                return counter;
            }
        }

        public int LastFramePos
        {
            get
            {
                return lastFramePos;
            }
        }

        public int PageNum
        {
            get
            {
                return pageNum;
            }
        }

        public int FilePos
        {
            get
            {
                return filePos;
            }
        }

        public bool SyncLost
        {
            get
            {
                return syncLost;
            }
        }

        public bool EndOfProcessedFrames
        {
            get
            {
                return (endOfData && (frameState == FrameStates.StartState));
            }
        }

        public void ReadFrame()
        {
            HuffmanCodeNode huffmanCodeNode = huffmanCodeTree;
            int framePos = 0;
            int lastFramePosWith0Bit = -1;
            int frameType = 0;
            int frameTypeBits = 0;
            int counterBits = 0;
            syncLost = false;
            while (!endOfData)
            {
                //The last 11 bits of the 128 byte (1024 bit) page are the Hamming Code and page
                //parity which this code skips.
                if ((bitPos >= 1013) || (page == null))
                {
                    bitPos = 0;
                    bool emptyPage = true;
                    //Skip empty pages (pages where all bits are 1)
                    while (emptyPage)
                    {
                        main.inputFile.Seek(pageNum);
                        page = main.inputFile.ReadPage();
                        pageNum++;
                        if ((pageNum & 0x1FF) == 0)
                            //We are at the end of a block of pages so go the first data page 
                            //within the next block of pages in this flight data stream.
                            pageNum += 0x202;
                        for (int bp = 0; bp < page.Length; bp++)
                            if (page[bp] != 0xFF)
                            {
                                emptyPage = false;
                                break;
                            }
                    }
                }
                if (pageNum >= main.inputFile.Length)
                {
                    endOfData = true;
                    filePos = main.inputFile.BytePos(pageNum);
                    break;
                }
                int wordPos = bitPos >> 4;
                if (wordPos != lastWordPos)
                {
                    w = (page[(wordPos << 1) | 1] << 8) | page[(wordPos << 1)];
                    lastWordPos = wordPos;
                    if ((w == 0xFEFE) && (wordPos != 63) && (frameState == FrameStates.WaitUntilEnd))
                    {
                        bitPos += 0x10;
                        filePos = main.inputFile.BytePos(pageNum - 1) + ((bitPos >> 3) & 0x7E);
                        //We have now finished reading this frame
                        break;
                    }
                }
                int bit = (w >> (0xF - (bitPos++ & 0xF))) & 1;
                switch (frameState)
                {
                    case FrameStates.StartState:
                        huffmanCodeNode = huffmanCodeTree;
                        framePos = 0;
                        lastFramePosWith0Bit = -1;
                        badFrame = false;
                        if (baseLineFrame = (bit == 1))
                        {
                            //This could be a baseline frame, read the frame type.
                            frameType = 0;
                            frameTypeBits = 0;
                            frameState = FrameStates.GetFrameType;
                        }
                        else
                        {
                            //Start decoding this non baseline frame.
                            counter += numFlightDataStreams;
                            frameState = FrameStates.DecompressFrame;
                        }
                        break;
                    case FrameStates.GetFrameType:
                        frameType = (frameType << 1) | bit;
                        if (++frameTypeBits >= 3)
                            if (frameType == 0)
                            {
                                //Read the counter value for this baseline frame.
                                counter = 0;
                                counterBits = 0;
                                frameState = FrameStates.GetCounter;
                            }
                            else
                            {
                                //This data is not a compressed frame.
                                badFrame = true;
                                frameState = FrameStates.WaitUntilEnd;
                            }
                        break;
                    case FrameStates.GetCounter:
                        counter = (counter << 1) | bit;
                        if (++counterBits >= 16)
                            //Start decoding this baseline frame.
                            frameState = FrameStates.DecompressFrame;
                        break;
                    case FrameStates.DecompressFrame:
                        if (bit == 0)
                            lastFramePosWith0Bit = framePos;
                        //Follow the Huffman code tree.
                        huffmanCodeNode = ((HuffmanCodeInteriorNode)huffmanCodeNode).GetChild(bit);
                        if (huffmanCodeNode.IsLeaf)
                        {
                            //We now have read a complete Huffman code. Get the difference.
                            int difference = ((HuffmanCodeLeafNode)huffmanCodeNode).Difference;
                            if (difference < 0)
                            {
                                //The Huffman code just read was the special loss of 
                                //synchronisation code. Wait for the frame marker word.
                                syncLost = true;
                                badFrame = true;
                                frameState = FrameStates.WaitUntilEnd;
                            }
                            else
                            {
                                //Add the difference to the 12 bit word for a non-baseline frame, 
                                //or overwrite the 12 bit word with the difference for a baseline 
                                //frame.
                                frame[framePos] = ((baseLineFrame ? 0 : frame[framePos]) + difference) & 0xFFF;
                                //Start reading the next Huffman code.
                                huffmanCodeNode = huffmanCodeTree;
                                if (++framePos >= frame.Length)
                                    //We now have a full frame, wait for the frame marker word.
                                    frameState = FrameStates.WaitUntilEnd;
                            }
                        }
                        break;
                    case FrameStates.WaitUntilEnd:
                        //The rest of the bits remaining before the frame marker word should all be 1
                        if (bit != 1)
                            badFrame = true;
                        break;
                }
            }
            lastFramePos = endOfData ? lastFramePosWith0Bit + 1 : framePos;
            if (lastFramePos > 764)
                superFrameNumber = (frame[764] >> 8) + 1;
            else
                if (superFrameNumber >= 0)
                    superFrameNumber = ((superFrameNumber + numFlightDataStreams - 1) % 16) + 1;
        }

        public void ReadGoodBaseLineFrame()
        {
            superFrameNumber = -1;
            //Keep reading frames until we get a good baseline frame.
            while (((!baseLineFrame) || badFrame) && (!endOfData))
            {
                frameState = FrameStates.StartState;
                ReadFrame();
            }
        }

        public void RecordHeader()
        {
            string line = "Subframe Counter";
            foreach (Parameter parameter in main.includedParametersListBox.Items)
                foreach (string parameterName in parameter.ParameterNames)
                    line += "," + parameterName;
            main.outputFile.WriteLine(line);
        }

        //This method writes the frame contents to the output file.
        public bool RecordFrame()
        {
            //Only record non baseline frames that have some data in them.
            if ((!baseLineFrame) && (lastFramePos > 0))
                //Cycle through each subframe within the frame.
                for (subFrameNumber = 1; subFrameNumber <= 4; subFrameNumber++)
                {
                    main.nextSubFrameCounter();
                    for (int lineNum = 0; ; lineNum++)
                        if ((lineNum <= 0) || (!main.maximumOneLinePerSubFrameCheckBox.Checked))
                        {
                            bool emptyLine = true;
                            string line = main.SubFrameCounter.ToString();
                            foreach (Parameter parameter in main.includedParametersListBox.Items)
                                foreach (ParameterColumn parameterColumn in parameter.Columns)
                                {
                                    string value = parameterColumn.GetValueAsString(lineNum, this);
                                    if (value == "")
                                    {
                                        if (main.replaceBlankValuesWithNullCheckBox.Checked)
                                            value = "null";
                                    }
                                    else
                                        emptyLine = false;
                                    line += "," + value;
                                }
                            if (emptyLine)
                                break;
                            else
                                if (((main.SubFrameCounter >= main.fromSubFrameNumber) || (main.fromSubFrameNumber == 0))
                                    && ((main.SubFrameCounter <= main.toSubFrameNumber) || (main.toSubFrameNumber == 0)))
                                {
                                    //Start recording output in a new file if the output has 
                                    //reached 30000 rows in length and the Split Output File option
                                    //has been selected.
                                    if (main.ReopenOutputFile)
                                        RecordHeader();
                                    main.outputFile.WriteLine(line);
                                }
                        }
                        else
                            break;
                }
            frameState = FrameStates.StartState;
            return syncLost;
        }
    }

    class GenerateOutput
    {
        private Main main = null;

        public bool Start(Main aMain, BackgroundWorker generateOutputBackgroundWorker)
        {
            main = aMain;
            //Construct the Huffman code tree.
            HuffmanCodeInteriorNode huffmanCodeTree = new HuffmanCodeInteriorNode();
            huffmanCodeTree.AddHuffmanCodesForPrefix("0", 0, 0);
            huffmanCodeTree.AddHuffmanCodesForPrefix("10", 1, 2);
            huffmanCodeTree.AddHuffmanCodesForPrefix("110", 3, 3);
            huffmanCodeTree.AddHuffmanCodesForPrefix("1110", 7, 4);
            huffmanCodeTree.AddHuffmanCodesForPrefix("111100", 15, 5);
            huffmanCodeTree.AddHuffmanCodesForPrefix("1111100", 31, 6);
            huffmanCodeTree.AddHuffmanCodesForPrefix("1111010", 63, 7);
            huffmanCodeTree.AddHuffmanCodesForPrefix("111111", 127, 8);
            huffmanCodeTree.AddHuffmanCodesForPrefix("1111101", 255, 9);
            huffmanCodeTree.AddHuffmanCodesForPrefix("11110110", 511, 10);
            huffmanCodeTree.AddHuffmanCodesForPrefix("111101110", 1023, 11);
            huffmanCodeTree.AddHuffmanCodesForPrefix("1111011110", 2047, 2);
            huffmanCodeTree.AddHuffmanCodesForPrefix("1111011111", -1, 0);  //This is the special Huffman code that marks loss of synchronisation.
            FlightDataStream[] flightDataStream = new FlightDataStream[2];
            for (int flightDataStreamNumber = 0; flightDataStreamNumber < flightDataStream.Length; flightDataStreamNumber++)
                flightDataStream[flightDataStreamNumber] = new FlightDataStream(main, huffmanCodeTree, flightDataStreamNumber, flightDataStream.Length);
            flightDataStream[0].RecordHeader();
            int highestPercentageReached = 0;
            bool syncLost = true;
            while (true)
            {
                if (generateOutputBackgroundWorker.CancellationPending)
                {
                    main.outputFile.WriteLine("Generation of output cancelled");
                    return (false);
                }
                if (syncLost)
                {
                    //We have reached the end of a section of compressed data. Find the next good
                    //baseline frame for both flight data streams.
                    for (int flightDataStreamNumber = 0; flightDataStreamNumber < flightDataStream.Length; flightDataStreamNumber++)
                        flightDataStream[flightDataStreamNumber].ReadGoodBaseLineFrame();
                    syncLost = false;
                }
                //Determine which flight data stream has the current frame with the lowest counter
                //value. This will be the frame to be recorded to the output next.
                int firstFlightDataStreamNumber = -1;
                int firstCounter = -1;
                for (int flightDataStreamNumber = 0; flightDataStreamNumber < flightDataStream.Length; flightDataStreamNumber++)
                    if (!flightDataStream[flightDataStreamNumber].EndOfProcessedFrames)
                    {
                        int counter = flightDataStream[flightDataStreamNumber].Counter;
                        if ((firstCounter < 0) || (((counter - firstCounter) & 0x8000) != 0))
                        {
                            firstFlightDataStreamNumber = flightDataStreamNumber;
                            firstCounter = counter;
                        }
                    }
                if (firstFlightDataStreamNumber < 0)
                    //No data to be recorded was found so the output is finished.
                    break;
                if (flightDataStream[firstFlightDataStreamNumber].RecordFrame())
                    //The loss of synchronisation code was found within the frame just recorded to 
                    //the output so we are at the end of this section of compressed data.
                    syncLost = true;
                flightDataStream[firstFlightDataStreamNumber].ReadFrame();
                int percentComplete = (int)(flightDataStream[firstFlightDataStreamNumber].PageNum * 100.0 / main.inputFile.Length);
                if (percentComplete > highestPercentageReached)
                {
                    highestPercentageReached = percentComplete;
                    generateOutputBackgroundWorker.ReportProgress(percentComplete);
                }
            }
            return (true);
        }
    }
}
