using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Xml;
using System.IO;

namespace AAL77FDRDecoder
{
    public partial class Main : Form
    {
        const string configurationFileName = "AAL77FDRDecoder.config.xml";

        public int fromSubFrameNumber = 0;
        public int toSubFrameNumber = 0;
        public PageFileStream inputFile = null;
        public StreamWriter outputFile = null;

        private string outputFileName = "";
        private int subFrameCounter = 0;
        private int rowNum = 0;
        private int fileNum = 0;

        public Main()
        {
            InitializeComponent();
        }

        private void SortExcludedParameters()
        {
            List<Parameter> parametersList = new List<Parameter>();
            foreach (Parameter parameter in excludedParametersListBox.Items)
                parametersList.Add(parameter);
            parametersList.Sort();
            excludedParametersListBox.Items.Clear();
            excludedParametersListBox.Items.AddRange(parametersList.ToArray());
        }

        private void displayFromToSubframeNumbers()
        {
            if (fromSubFrameNumber == 0)
                subFramesFromTextBox.Text = "";
            else
                subFramesFromTextBox.Text = fromSubFrameNumber.ToString();
            if (toSubFrameNumber == 0)
                subFramesToTextBox.Text = "";
            else
                subFramesToTextBox.Text = toSubFrameNumber.ToString();
        }

        private void LoadConfiguration()
        {
            excludedParametersListBox.Items.Clear();
            excludedParametersListBox.SelectionMode = SelectionMode.MultiExtended;
            includedParametersListBox.Items.Clear();
            includedParametersListBox.SelectionMode = SelectionMode.MultiExtended;
            ParametersList parametersList = new ParametersList();
            XmlReaderSettings settings = new XmlReaderSettings();
            settings.IgnoreComments = true;
            settings.IgnoreProcessingInstructions = true;
            settings.IgnoreWhitespace = true;
            try
            {
                using (XmlReader reader = XmlReader.Create(configurationFileName, settings))
                {
                    reader.ReadStartElement("Settings");
                    while (reader.IsStartElement())
                    {
                        bool elementRecognised = false;
                        if (reader.IsStartElement("RawFDRFileName"))
                        {
                            elementRecognised = true;
                            rawFDRFileNameTextBox.Text = reader.ReadElementContentAsString();
                        }
                        if (reader.IsStartElement("AllSubFrames"))
                        {
                            elementRecognised = true;
                            allSubFramesRadioButton.Checked = reader.ReadElementContentAsBoolean();
                        }
                        if (reader.IsStartElement("FinalFlight"))
                        {
                            elementRecognised = true;
                            finalFlightRadioButton.Checked = reader.ReadElementContentAsBoolean();
                        }
                        if (reader.IsStartElement("SubFrames"))
                        {
                            elementRecognised = true;
                            subFramesRadioButton.Checked = reader.ReadElementContentAsBoolean();
                        }
                        if (reader.IsStartElement("FromSubFrameNumber"))
                        {
                            elementRecognised = true;
                            fromSubFrameNumber = reader.ReadElementContentAsInt();
                        }
                        if (reader.IsStartElement("ToSubFrameNumber"))
                        {
                            elementRecognised = true;
                            toSubFrameNumber = reader.ReadElementContentAsInt();
                        }
                        if (reader.IsStartElement("SplitOutputFile"))
                        {
                            elementRecognised = true;
                            splitOutputFileCheckBox.Checked = reader.ReadElementContentAsBoolean();
                        }
                        if (reader.IsStartElement("MaximumOneLinePerSubFrame"))
                        {
                            elementRecognised = true;
                            maximumOneLinePerSubFrameCheckBox.Checked = reader.ReadElementContentAsBoolean();
                        }
                        if (reader.IsStartElement("ReplaceBlankValuesWithNull"))
                        {
                            elementRecognised = true;
                            replaceBlankValuesWithNullCheckBox.Checked = reader.ReadElementContentAsBoolean();
                        }
                        if (reader.IsStartElement("ExcludedParameters"))
                        {
                            elementRecognised = true;
                            reader.ReadStartElement();
                            while (reader.IsStartElement("Parameter"))
                            {
                                string s = reader.ReadElementContentAsString();
                                int i = parametersList.IndexOf(s);
                                if (i >= 0)
                                {
                                    excludedParametersListBox.Items.Add(parametersList[i]);
                                    parametersList.RemoveAt(i);
                                }
                            }
                        }
                        if (reader.IsStartElement("IncludedParameters"))
                        {
                            elementRecognised = true;
                            reader.ReadStartElement();
                            while (reader.IsStartElement("Parameter"))
                            {
                                string s = reader.ReadElementContentAsString();
                                int i = parametersList.IndexOf(s);
                                if (i >= 0)
                                {
                                    includedParametersListBox.Items.Add(parametersList[i]);
                                    parametersList.RemoveAt(i);
                                }
                            }
                        }
                        if (!elementRecognised)
                            reader.ReadStartElement();
                        if (reader.NodeType == XmlNodeType.EndElement)
                            reader.ReadEndElement();
                    }
                }
            }
            catch (Exception)
            {
                rawFDRFileNameTextBox.Text = "";
                finalFlightRadioButton.Checked = true;
                splitOutputFileCheckBox.Checked = false;
                maximumOneLinePerSubFrameCheckBox.Checked = true;
                replaceBlankValuesWithNullCheckBox.Checked = false;
            }
            finally
            {
                //If there were parameters that were not recorded in the configuration file as being in the included list or the excluded list, then add them to the excluded list
                excludedParametersListBox.Items.AddRange(parametersList.ToArray());
                SortExcludedParameters();
                displayFromToSubframeNumbers();
            }
        }

        private void Main_Load(object sender, EventArgs e)
        {
            versionLabel.Text = "Version 1.10";
            helpProvider.SetShowHelp(this, true);
            helpProvider.HelpNamespace = "http://www.warrenstutt.com/AAL77FDRDecoder/help.html";
            LoadConfiguration();
        }

        private void chooseButton_Click(object sender, EventArgs e)
        {
            OpenFileDialog chooseFileDialog = new OpenFileDialog();
            chooseFileDialog.CheckFileExists = true;
            chooseFileDialog.FileName = "American 77.fdr";
            chooseFileDialog.Multiselect = false;
            chooseFileDialog.RestoreDirectory = true;
            chooseFileDialog.Title = "Choose AAL77 Raw FDR File";
            if (chooseFileDialog.ShowDialog() == DialogResult.OK)
                rawFDRFileNameTextBox.Text = chooseFileDialog.FileName;
        }

        private void allSubFramesRadioButton_CheckedChanged(object sender, EventArgs e)
        {
            if (allSubFramesRadioButton.Checked)
            {
                fromSubFrameNumber = 0;
                toSubFrameNumber = 0;
                displayFromToSubframeNumbers();
            }
        }

        private void finalFlightRadioButton_CheckedChanged(object sender, EventArgs e)
        {
            if (finalFlightRadioButton.Checked)
            {
                fromSubFrameNumber = 146640;
                toSubFrameNumber = 0;
                displayFromToSubframeNumbers();
            }
        }

        private void subFramesRadioButton_CheckedChanged(object sender, EventArgs e)
        {
            if (subFramesRadioButton.Checked)
            {
                fromSubFrameNumber = 0;
                toSubFrameNumber = 0;
                displayFromToSubframeNumbers();
            }
        }

        private void subFramesFromTextBox_Enter(object sender, EventArgs e)
        {
            subFramesRadioButton.Checked = true;
            subFramesFromTextBox.SelectAll();
        }

        private void subFramesToTextBox_Enter(object sender, EventArgs e)
        {
            subFramesRadioButton.Checked = true;
            subFramesToTextBox.SelectAll();
        }

        private void checkFromToSubframeNumbers()
        {
            if ((fromSubFrameNumber > toSubFrameNumber) && (toSubFrameNumber > 0))
            {
                int subFrameNumber = fromSubFrameNumber;
                fromSubFrameNumber = toSubFrameNumber;
                toSubFrameNumber = subFrameNumber;
                displayFromToSubframeNumbers();
            }
        }

        private void subFramesFromTextBox_Leave(object sender, EventArgs e)
        {
            try
            {
                if (subFramesFromTextBox.Text == "")
                    fromSubFrameNumber = 0;
                else
                {
                    fromSubFrameNumber = int.Parse(subFramesFromTextBox.Text);
                    if (fromSubFrameNumber < 1)
                    {
                        MessageBox.Show("Subframes From must be a number greater than 0 or blank for beginning");
                        subFramesFromTextBox.Focus();
                        subFramesFromTextBox.SelectAll();
                    }
                    else
                        checkFromToSubframeNumbers();
                }
            }
            catch (Exception)
            {
                MessageBox.Show("Subframes From must be a number");
                subFramesFromTextBox.Focus();
                subFramesFromTextBox.SelectAll();
            }
        }

        private void subFramesToTextBox_Leave(object sender, EventArgs e)
        {
            try
            {
                if (subFramesToTextBox.Text == "")
                    toSubFrameNumber = 0;
                else
                {
                    toSubFrameNumber = int.Parse(subFramesToTextBox.Text);
                    if (toSubFrameNumber < 1)
                    {
                        MessageBox.Show("Subframes To must be a number greater than 0 or blank for end");
                        subFramesToTextBox.Focus();
                        subFramesToTextBox.SelectAll();
                    }
                    else
                        checkFromToSubframeNumbers();
                }
            }
            catch (Exception)
            {
                MessageBox.Show("Subframes To must be a number");
                subFramesToTextBox.Focus();
                subFramesToTextBox.SelectAll();
            }        
        }

        private void SaveConfiguration()
        {
            XmlWriterSettings settings = new XmlWriterSettings();
            settings.Indent = true;
            settings.IndentChars = ("    ");
            using (XmlWriter writer = XmlWriter.Create(configurationFileName, settings))
            {
                writer.WriteStartElement("Settings");
                writer.WriteStartElement("RawFDRFileName");
                writer.WriteValue(rawFDRFileNameTextBox.Text);
                writer.WriteEndElement();
                writer.WriteStartElement("AllSubFrames");
                writer.WriteValue(allSubFramesRadioButton.Checked);
                writer.WriteEndElement();
                writer.WriteStartElement("FinalFlight");
                writer.WriteValue(finalFlightRadioButton.Checked);
                writer.WriteEndElement();
                writer.WriteStartElement("SubFrames");
                writer.WriteValue(subFramesRadioButton.Checked);
                writer.WriteEndElement();
                writer.WriteStartElement("FromSubFrameNumber");
                writer.WriteValue(fromSubFrameNumber);
                writer.WriteEndElement();
                writer.WriteStartElement("ToSubFrameNumber");
                writer.WriteValue(toSubFrameNumber);
                writer.WriteEndElement();
                writer.WriteStartElement("SplitOutputFile");
                writer.WriteValue(splitOutputFileCheckBox.Checked);
                writer.WriteEndElement();
                writer.WriteStartElement("MaximumOneLinePerSubFrame");
                writer.WriteValue(maximumOneLinePerSubFrameCheckBox.Checked);
                writer.WriteEndElement();
                writer.WriteStartElement("ReplaceBlankValuesWithNull");
                writer.WriteValue(replaceBlankValuesWithNullCheckBox.Checked);
                writer.WriteEndElement();
                writer.WriteStartElement("ExcludedParameters");
                foreach (Parameter parameter in excludedParametersListBox.Items)
                {
                    writer.WriteStartElement("Parameter");
                    writer.WriteValue(parameter.ToString());
                    writer.WriteEndElement();
                }
                writer.WriteEndElement();
                writer.WriteStartElement("IncludedParameters");
                foreach (Parameter parameter in includedParametersListBox.Items)
                {
                    writer.WriteStartElement("Parameter");
                    writer.WriteValue(parameter.ToString());
                    writer.WriteEndElement();
                }
                writer.WriteEndElement();
                writer.WriteEndElement();
                writer.Flush();
            }
        }

        private void Main_FormClosed(object sender, FormClosedEventArgs e)
        {
            SaveConfiguration();
        }

        private void includeParametersButton_Click(object sender, EventArgs e)
        {
            List<object> itemsToRemove = new List<object>();
            foreach (object item in excludedParametersListBox.SelectedItems)
            {
                itemsToRemove.Add(item);
                includedParametersListBox.Items.Add(item);
            }
            foreach (object item in itemsToRemove)
                excludedParametersListBox.Items.Remove(item);
        }

        private void includeAllParametersButton_Click(object sender, EventArgs e)
        {
            foreach (object item in excludedParametersListBox.Items)
                includedParametersListBox.Items.Add(item);
            excludedParametersListBox.Items.Clear();
        }

        private void excludeParametersButton_Click(object sender, EventArgs e)
        {
            List<object> itemsToRemove = new List<object>();
            foreach (object item in includedParametersListBox.SelectedItems)
            {
                itemsToRemove.Add(item);
                excludedParametersListBox.Items.Add(item);
            }
            foreach (object item in itemsToRemove)
                includedParametersListBox.Items.Remove(item);
            SortExcludedParameters();
        }

        private void excludeAllParametersButton_Click(object sender, EventArgs e)
        {
            foreach (object item in includedParametersListBox.Items)
                excludedParametersListBox.Items.Add(item);
            includedParametersListBox.Items.Clear();
            SortExcludedParameters();
        }

        public int SubFrameCounter
        {
            get
            {
                return subFrameCounter;
            }
        }

        public void nextSubFrameCounter()
        {
            subFrameCounter++;
        }

        //Start recording output in a new file if the output has reached 30000 rows in length and
        //the Split Output File option has been selected.
        public bool ReopenOutputFile
        {
            get
            {
                if ((++rowNum >= 30000) && (splitOutputFileCheckBox.Checked))
                {
                    fileNum++;
                    int i = outputFileName.LastIndexOf('.');
                    if (i < 0)
                        i = outputFileName.Length;
                    string newOutputFileName = outputFileName.Insert(i, " " + fileNum.ToString());
                    outputFile.Close();
                    outputFile = new StreamWriter(newOutputFileName);
                    rowNum = 0;
                    return (true);
                }
                return (false);
            }
        }

        private void startButton_Click(object sender, EventArgs e)
        {
            if (includedParametersListBox.Items.Count < 1)
                MessageBox.Show("No parameters have been selected to include in the output file!");
            else
            {
                SaveFileDialog outputFileDialog = new SaveFileDialog();
                outputFileDialog.DefaultExt = "csv";
                outputFileDialog.Filter = "Comma Seperated Value files (*.csv)|*.csv";
                outputFileDialog.FilterIndex = 1;
                outputFileDialog.OverwritePrompt = true;
                outputFileDialog.RestoreDirectory = true;
                outputFileDialog.Title = "CSV File To Be Generated";
                if (outputFileDialog.ShowDialog() == DialogResult.OK)
                {
                    try
                    {
                        inputFile = new PageFileStream(rawFDRFileNameTextBox.Text);
                        try
                        {
                            outputFileName = outputFileDialog.FileName;
                            outputFile = new StreamWriter(outputFileName);
                            subFrameCounter = 0;
                            rowNum = 0;
                            fileNum = 0;
                            Enabled = false;
                            GenerationProgress generationProgress = new GenerationProgress();
                            generationProgress.main = this;
                            generationProgress.ShowDialog();
                            Enabled = true;
                            outputFile.Close();
                            inputFile.Close();
                        }
                        catch (Exception exception)
                        {
                            inputFile.Close();
                            MessageBox.Show("The following error occurred when creating the output CSV file: " + exception.Message);
                        }
                    }
                    catch (Exception exception)
                    {
                        MessageBox.Show("The following error occurred when opening the Raw FDR file: " + exception.Message);
                    }
                }
            }
        }
    }
}