using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace AAL77FDRDecoder
{
    public partial class GenerationProgress : Form
    {
        public Main main = null;

        public GenerationProgress()
        {
            InitializeComponent();
        }

        private void GenerationProgress_Load(object sender, EventArgs e)
        {
            generateOutputBackgroundWorker.RunWorkerAsync();
        }

        private void generateOutputBackgroundWorker_DoWork(object sender, DoWorkEventArgs e)
        {
            GenerateOutput generateOutput = new GenerateOutput();
            if (!generateOutput.Start(main, generateOutputBackgroundWorker))
                e.Cancel = true;
        }

        private void generateOutputBackgroundWorker_RunWorkerCompleted(object sender, RunWorkerCompletedEventArgs e)
        {
            if (e.Error != null)
            {
                MessageBox.Show(e.Error.Message);
            }
            Close();
        }

        private void generateOutputBackgroundWorker_ProgressChanged(object sender, ProgressChangedEventArgs e)
        {
            generationProgressBar.Value = e.ProgressPercentage;
        }

        private void GenerationProgress_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (generateOutputBackgroundWorker.IsBusy)
            {
                generateOutputBackgroundWorker.CancelAsync();
                MessageBox.Show("Generation of output cancelled");
            }
        }
    }
}